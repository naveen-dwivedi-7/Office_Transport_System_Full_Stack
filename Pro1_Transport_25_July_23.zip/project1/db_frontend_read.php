<?php


include_once('./admin/db/db.php');

function get_all_location_id_vehicle_id_by_time_id($id)
{
    global $conn;
    $sql = "SELECT `route_id`,`location_id`, `vehicle_id` FROM `routes` WHERE time_id=$id";
    $result = mysqli_query($conn, $sql);

    return $result;
}




function get_time_slot_by_time_id($time_id)
{
    global $conn;
    $sql = "SELECT  `time_slot` FROM `timing` WHERE time_id=$time_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $timeSlot = $row['time_slot'];
        return $timeSlot;
    }
}
function get_all_distinct_morning_time_ids()
{
    global $conn;
    $sql = "SELECT  DISTINCT `time_id` FROM `routes` WHERE timeperiod='M'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $morning_time_ids[] = $row['time_id'];
        }
    }
    return $morning_time_ids;
}

function get_all_distinct_evening_time_ids()
{
    global $conn;
    $sql = "SELECT  DISTINCT `time_id` FROM `routes` WHERE timeperiod='E'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $evening_time_ids[] = $row['time_id'];
        }
    }
    return $evening_time_ids;
}

function get_all_distinct_time_ids()
{
    global $conn;
    $sql = "SELECT  DISTINCT `time_id` FROM `routes`";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $all_time_ids[] = $row['time_id'];
        }
    }
    return $all_time_ids;
}
function get_all_route_ids()
{
    global $conn;
    $sql = "SELECT `route_id` FROM `routes`";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $all_route_ids[] = $row['route_id'];
        }
    }
    return $all_route_ids;
}





function get_number_of_routes_from_given_timeslot($time_id)
{
    global $conn;
    $sql = "SELECT COUNT(route_id) AS count FROM routes WHERE time_id=$time_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $num_routes = $row['count'];
        return $num_routes;
    }


}



function get_number_of_routes_from_given_location($loc_id)
{
    global $conn;
    $sql = "SELECT COUNT(route_id) AS count FROM routes WHERE location_id=$loc_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $num_routes = $row['count'];
        return $num_routes;
    }


}

function get_location_name_by_location_id($loc_id)
{
    global $conn;
    $sql = "SELECT `location_name` FROM `locations` WHERE location_id=$loc_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_assoc($result);
        $location_name = $row['location_name'];
        return $location_name;
    }
}

function get_parent_id_by_location_id($loc_id)
{
    global $conn, $parent_id;
    $query = "SELECT  `location_parent_id` FROM `locations` WHERE location_id=$loc_id";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_assoc($result);
        $parent_id = $row['location_parent_id'];

    }


    return $parent_id;

}

//if parent_id==0 , area == same location name itself
function get_parent_area_by_location_id($loc_id)
{
    global $conn;
    $p_id = get_parent_id_by_location_id($loc_id);

    if ($p_id == 0) {
        $area_name = get_location_name_by_location_id($loc_id);
    }
    if ($p_id != 0) {
        $area_name = get_location_name_by_location_id($p_id);
    }

    return $area_name;

}




function get_distinct_morning_location_ids()
{
    global $conn;
    $sql = "SELECT  DISTINCT `location_id` FROM `routes` WHERE timeperiod='M'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $morning_location_ids[] = $row['location_id'];
        }
    }
    return $morning_location_ids;

}
function get_all_distinct_location_ids()
{
    global $conn;
    $sql = "SELECT  DISTINCT `location_id` FROM `routes`";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $all_location_ids[] = $row['location_id'];
        }
    }
    return $all_location_ids;

}

function get_location_distance_by_location_id($loc_id)
{
    global $conn;
    $sql = "SELECT  `location_distance` FROM `locations` WHERE location_id=$loc_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $location_distance = $row['location_distance'];
        return $location_distance;
    }
}
function get_vehicle_data_by_vehicle_id($veh_id)
{
    global $conn;
    $sql = "SELECT  `model`,`capacity`  FROM `vehicle` WHERE vehicle_id=$veh_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $arr['model'] = $row['model'];
        $arr['capacity'] = $row['capacity'];

        return $arr;

    }
}

function get_morning_time_id_vehicle_id_by_location_id($id)
{
    global $conn;
    $sql = "SELECT  `time_id`, `vehicle_id` FROM `routes` WHERE location_id=$id AND timeperiod='M'";
    $result = mysqli_query($conn, $sql);

    return $result;
}
function get_all_time_id_vehicle_id_by_location_id($id)
{
    global $conn;
    $sql = "SELECT  `time_id`, `vehicle_id` FROM `routes` WHERE location_id=$id";
    $result = mysqli_query($conn, $sql);

    return $result;
}
function get_all_route_id_time_id_vehicle_id_by_location_id_morning($id)
{
    global $conn;
    $sql = "SELECT `route_id`,`time_id`, `vehicle_id` FROM `routes` WHERE location_id=$id AND timeperiod='M'";
    $result = mysqli_query($conn, $sql);

    return $result;
}
function get_all_route_id_time_id_vehicle_id_by_location_id_evening($id)
{
    global $conn;
    $sql = "SELECT `route_id`, `time_id`, `vehicle_id` FROM `routes` WHERE location_id=$id AND timeperiod='E'";
    $result = mysqli_query($conn, $sql);

    return $result;
}

function get_all_route_morning_data()
{
    global $conn;
    $query = "SELECT * FROM routes WHERE timeperiod='M'";
    $result = mysqli_query($conn, $query);

    return $result;
}
function get_all_route_evening_data()
{
    global $conn;
    $query = "SELECT * FROM routes WHERE timeperiod='E'";
    $result = mysqli_query($conn, $query);
    return $result;
}
function get_parent_area_names()
{
    global $conn;
    $query = "SELECT  `location_name` FROM `locations` WHERE location_parent_id=0";
    $result = mysqli_query($conn, $query);
    return $result;


}

function get_timePeriod_by_time_id()
{
    global $conn;
    $query = "SELECT `timeperiod` FROM `timing` WHERE time_id=29;";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $timeperiod = $row['$timeperiod'];
    }
    return $timeperiod;

}
function get_all_route_data_by_route_id($id)
{

    global $conn;
    $query = "SELECT * FROM `routes` WHERE route_id='$id'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $arr['route_id'] = $row['route_id'];
        $arr['timeperiod'] = $row['timeperiod'];
        $arr['time_id'] = $row['time_id'];
        $arr['location_id'] = $row['location_id'];
        $arr['vehicle_id'] = $row['vehicle_id'];
        $arr['status'] = $row['status'];
        $arr['datetime'] = $row['datetime'];
        return $arr;





    }

}


function get_time_ids_by_selected_location_id($id)
{
    //SELECT  `time_id` FROM `routes` WHERE location_id=17
    global $conn;
    $sql = "SELECT DISTINCT `time_id` FROM `routes` WHERE location_id='$id'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $all_time_ids[] = $row['time_id'];
        }
    }
    return $all_time_ids;

}
function get_route_ids_by_selected_time_id($id)
{
    //SELECT `route_id` FROM `routes` WHERE time_id=31
    global $conn;
    $sql = "SELECT DISTINCT `route_id` FROM `routes` WHERE time_id='$id'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $all_route_ids[] = $row['route_id'];
        }
    }
    return $all_route_ids;
}