<?php
$page_name = 'Location Form Page';

include_once('templates/header.php');
include_once("db/location_read.php");


$result = get_parent_id();
if ($result->num_rows > 0) {
    $locations = mysqli_fetch_all($result, MYSQLI_ASSOC);

}

$action = $_GET['action'];

if (isset($action)) {
    if ($action == "edit") {
        $uid = $_GET['id'];

        $data = get_location_data_by_id($uid);

        $location_name = $data['location_name'];
        $location_distance = $data['location_distance'];
        $location_parent_id = $data['location_parent_id'];

        $status = $data['status'];

        $var = "Update Location";


    } elseif ($action == "add") {
        $location_name = "";
        $location_distance = "";
        $location_parent_id = "";
        $location_id = "";
        $status = '1';
        $pid = 0;
        $var = "Save Location";


    }

}
?>

<body>

    <div class="container mt-3">
        <h2>Enter Location Details</h2>
        <form id="location_form" , method="POST">
            <div class=" mb-3 mt-3">
                <label for="location_name"> Location :</label>
                <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                <input type="text" class="form-control" id="location_name" placeholder="Enter Location Name"
                    name="location_name" value="<?php echo $location_name ?>">
            </div>
            <div class=" mb-3 mt-3">
                <label for="location_distance"> Distance From office(in KM):</label>
                <input type="number" class="form-control" id="location_distance"
                    placeholder="Enter  Distance From office" min=0 name="location_distance"
                    value="<?php echo $location_distance ?>">
            </div>

            <div class="mb-3 mt-3">
                <label for="location_parent_id">Select Area:</label>
                <select name="location_parent_id" class="form-select">

                    <option>
                        <?php echo $location_parent_id ?>
                    </option>

                    <option value="0">

                        Select As Parent
                    </option>
                    <?php

                    foreach ($locations as $location) {
                        $selected = '';
                        if ($action == 'edit' && $location_parent_id == $location['location_id']) {
                            $selected = 'selected';
                        }
                        ?>

                        <option value="<?php echo $location['location_id']; ?>" <?php echo $selected; ?>>
                            <?php echo "$location[location_name]" ?>
                        </option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3 mt-3">
                <label for="status">Location Status:</label>
                <input type="radio" name="status" id="status" value="1" <?php echo ($status == '1') ? "CHECKED" : " " ?> />Enabled

                <input type="radio" name="status" id="status" value="0" <?php echo ($status == '0') ? "CHECKED" : " " ?> />Disabled
            </div>

            <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
            <input type="submit" class="btn btn-primary" name="submit" value="<?php echo $var; ?>" />
        </form>
        <br>
        <a href='http://practice.indianexpress.com/project1/admin/location_list.php'>
            <button class="btn btn-dark">
                Show Location List
            </button>
    </div>

</body>
<?php include("templates/footer.php"); ?>