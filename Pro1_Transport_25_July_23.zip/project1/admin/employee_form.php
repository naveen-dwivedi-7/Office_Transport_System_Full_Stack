<?php
$page_name = 'Employee Form Page';
include_once('templates/header.php');
include_once("db/timing_read.php");
include_once("db/employee_read.php");



$result = get_all_timing_data();
if ($result->num_rows > 0) {
    $timings = mysqli_fetch_all($result, MYSQLI_ASSOC);

}



$action = $_GET['action'];
if (isset($action)) {
    if ($action == "edit") {
        $uid = $_GET['id'];

        $data = get_employee_data_by_id($uid);
        $emp_time_ids = get_employee_time_id_by_id($uid);
        $time_ids_checked_array = array();
        while ($row2 = mysqli_fetch_assoc($emp_time_ids)) {
            $time_ids_checked_array[] = $row2['time_id'];

        }

        $fname = $data['fname'];
        $lname = $data['lname'];
        $email = $data['email'];
        $gender = $data['gender'];

        $dob = $data['dob'];
        $emp_profile = $data['emp_profile'];

        $location_id = $data['location_id'];
        $status = $data['status'];

        $var = "Update Employee";

    } elseif ($action == "add") {

        $fname = "";
        $lname = "";
        $email = "";
        $gender = "";

        $dob = "";
        $emp_profile = "";
        $location_id = "";
        $status = '1';

        $var = "Save Employee";

    }

}
echo "<pre>";

$res = get_all_employee_timing_relation_data();
if ($res->num_rows > 0) {
    $emp_time_data = mysqli_fetch_all($res, MYSQLI_ASSOC);

}





echo "</pre>";
?>

<body>

    <div class="container mt-3">
        <h2>Enter Employee Details</h2>
        <form id="employee_form" enctype="multipart/form-data" method="POST">
            <div class="form-group">

                <div class="mb-3 mt-3">
                    <label for="fname">First name:</label>
                    <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                    <input type="text" class="form-control" id="fname" placeholder="Enter first name" required
                        name="fname" value="<?php echo $fname ?>">
                </div>
                <div class="mb-3 mt-3">
                    <label for="lname">Last name:</label>
                    <input type="text" class="form-control" id="lname" placeholder="Enter last name" name="lname"
                        value="<?php echo $lname ?>">
                </div>
                <div class="mb-3 mt-3">
                    <label for="email">E mail:</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter email" name="email"
                        value="<?php echo $email ?>">
                </div>


                <div class="mb-3">
                    <label for="dob">DOB:</label>
                    <input type="date" class="form-control" id="dob" placeholder="Enter Date of birth" name="dob"
                        value="<?php echo $dob ?>">
                </div>
                <div class="mb-3">
                    <label for="emp_profile" class="form-label">Upload Profile Image:</label>
                    <input type="file" class="form-control" name="emp_profile" id="emp_profile" placeholder=""
                        value="<?php echo $emp_profile ?>">
                    <?php
                    echo "$emp_profile";
                    ?>
                </div>

                <div class="mb-3 mt-3">
                    <label for="required">Gender:</label>
                    <input type="radio" name="gender" id="gender" value="male" <?php echo ($gender == 'male') ? "CHECKED" : " " ?> />Male

                    <input type="radio" name="gender" id="gender" value="female" <?php echo ($gender == 'female') ? "CHECKED" : " " ?> />Female
                </div>

                <hr>

                <div class="mb-3 mt-3">
                    <label for="location_id">Select Location:</label>
                    <select name="location_id" class="form-select">
                        <option>
                            <?php echo $location_id ?>
                        </option>
                        <?php
                        categoryTree();



                        ?>

                    </select>
                </div>
                <div class="mb-3 mt-3">
                    <label for="timing_list[]">Select Preffered Time Slot:</label>

                    <?php foreach ($timings as $timing) {

                        $checked = "";
                        if ($action == "edit") {

                            if (is_array($time_ids_checked_array) && in_array($timing['time_id'], $time_ids_checked_array)) {
                                $checked = 'checked';
                            }
                        }
                        ?>
                        <li>
                            <input type="checkbox" required name="timing_list[]" value="
                                            <?php echo $timing['time_id'] ?>" <?php echo $checked; ?>>
                            <?php echo $timing['time_slot'] ?>
                        </li>

                    <?php } ?>


                </div>
                <div class="mb-3 mt-3">
                    <label for="status">Employee Status:</label>
                    <input type="radio" name="status" id="status" value="1" <?php echo ($status == '1') ? "CHECKED" : " " ?> />Enabled

                    <input type="radio" name="status" id="status" value="0" <?php echo ($status == '0') ? "CHECKED" : " " ?> />Disabled
                </div>

                <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
                <input type="submit" class="btn btn-primary" name="submit" value="<?php echo $var; ?>">
        </form>
        <br>
        <br>

    </div>
    <a href='http://practice.indianexpress.com/project1/admin/employee_list.php'>
        <button class="btn btn-dark">
            Show Employee List
        </button>

</body>
</div>
<?php include("templates/footer.php");



?>