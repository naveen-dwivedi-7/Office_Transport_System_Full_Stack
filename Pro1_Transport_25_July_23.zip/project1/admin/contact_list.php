<?php

include_once("db/contact_read.php");
$page_name = 'Enquiry List Page';
include_once('templates/header.php');



$start_from = get_start_from_value_contact($cur_page);
$total_number_of_pages = get_total_pages_contact();


?>

<body>

    <div class="container-xl">
        <br>


        <div class="col-md-12">
            <br>

            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Message</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="contact_read.php">

                    <?php display_contact_table($cur_page); ?>



                </tbody>
            </table>
        </div>

        <?php
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>