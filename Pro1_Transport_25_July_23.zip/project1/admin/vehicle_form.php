<?php
$page_name = 'Vehicle Form Page';

include_once('templates/header.php');
include_once("db/vehicle_read.php");

$action = $_GET['action'];
if (isset($action)) {
    if ($action == "edit") {
        $uid = $_GET['id'];

        $data = get_vehicle_data_by_id($uid);

        $vehicle_no = $data['vehicle_no'];
        $model = $data['model'];
        $capacity = $data['capacity'];
        $status = $data['status'];

        $var = "Update Vehicle";

    } elseif ($action == "add") {
        $vehicle_no = "";
        $model = "";
        $capacity = "";
        $status = '1';


        $var = "Save Vehicle";

    }

}
?>

<body>

    <div class="container mt-3">
        <h2>Enter Vehicle Details</h2>
        <form id="vehicle_form" , method="POST">

            <div class="mb-3 mt-3">
                <label for="vehicle_no">Vehicle Reg No.:</label>
                <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                <input type="text" class="form-control" id="vehicle_no" placeholder="Enter Vehicle No."
                    name="vehicle_no" value="<?php echo $vehicle_no ?>">
            </div>
            <div class="mb-3 mt-3">
                <label for="model">Model:</label>
                <input type="text" class="form-control" id="model" placeholder="Enter Model" name="model"
                    value="<?php echo $model ?>">
            </div>
            <div class="mb-3 mt-3">
                <label for="capacity">Capacity:</label>
                <input type="number" class="form-control" id="capacity" placeholder="Enter Capacity" min='1'
                    name="capacity" value="<?php echo $capacity ?>">
            </div>
            <div class="mb-3 mt-3">
                <label for="status">Vehicle Status:</label>
                <input type="radio" name="status" id="status" value="1" <?php echo ($status == '1') ? "CHECKED" : " " ?> />Enabled


                <input type="radio" name="status" id="status" value="0" <?php echo ($status == '0') ? "CHECKED" : " " ?> />Disabled
            </div>
            <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
            <input type="submit" class="btn btn-primary" name="submit" value="<?php echo $var; ?>">
        </form>
        <br>
        <a href='http://practice.indianexpress.com/project1/admin/vehicle_list.php'>
            <button class="btn btn-dark">
                Show Vehicle List
            </button>
    </div>

</body>
<?php include("templates/footer.php"); ?>