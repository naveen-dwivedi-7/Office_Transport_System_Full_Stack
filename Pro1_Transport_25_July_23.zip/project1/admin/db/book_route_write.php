<?php

include_once("book_route_read.php");
print_r($_POST);
$email = $_POST['email'];
$route_id = $_POST['route_id'];

$capacity = get_capacity_by_route_id($route_id);
$already_booked_route = get_no_of_booked_route($route_id);
// echo $already_booked_route;
// echo $capacity;

$num_emails = no_of_email_already_in_employee_table($email);
if ($num_emails == 0) {
    $msg = "Register yourself first..sorry you cannot book route beacuse you are not registered";
    header("Location: http://practice.indianexpress.com/project1/book_route.php?msg=$msg");
} else {
    // echo $already_booked_route;
    // echo $capacity;

    if ($already_booked_route <= $capacity) {
        // die();
        $emp_id = get_employee_id_by_email($email);
        insert_employee_route_relation($route_id, $emp_id);
    } else {
        // echo "overflows";
        // die();
        $msg = "No seat available..sorry you cannot book route beacuse all routes are booked already";
        header("Location: http://practice.indianexpress.com/project1/book_route.php?msg=$msg");
    }

}

function insert_employee_route_relation($route_id, $emp_id)
{
    global $conn;
    $msg = "Congratulation! Your route is booked ";

    echo $sql = "INSERT INTO `route_employee_relation`(`route_id`,`emp_id`) VALUES ($route_id,$emp_id)";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // echo "record inserted successfully";
        header("Location: http://practice.indianexpress.com/project1/book_route.php?msg=$msg");

    }




}

?>