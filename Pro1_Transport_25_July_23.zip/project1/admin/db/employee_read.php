<?php
include("db.php");
// include('location_read.php');
// include('employee_read.php');
if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
  include_once('../templates/common.php');
  $page = 1;
  if (isset($_POST['page'])) {
    $page = $_POST['page'];
  }

  display_employee_table($page);
} else {
  include_once('templates/common.php');
}


/*
 * Function -get_all_employee_data() : It fetch data from table employee and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- object , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */

function get_all_employee_data()
{
  global $conn;
  $query = "SELECT * FROM employee ";
  $result = mysqli_query($conn, $query);

  return $result;
}


/*
 *Function - get_all_admin_data_by_id(): It fetch a single row  from  table employee  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-employee.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */

function get_employee_data_by_id($id)
{
  global $conn;
  $query = "SELECT * FROM employee WHERE emp_id= $id";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['fname'] = $row['fname'];
    $arr['lname'] = $row['lname'];
    $arr['email'] = $row['email'];
    $arr['gender'] = $row['gender'];
    $arr['dob'] = $row['dob'];
    $arr['emp_profile'] = $row['emp_profile'];
    $arr['location_id'] = $row['location_id'];
    $arr['status'] = $row['status'];

    return $arr;

  }



}

function get_employee_time_slots_by_id($id)
{
  global $conn;
  $query = "SELECT timing.time_slot FROM timing INNER JOIN employee_timing_relation ON timing.time_id = employee_timing_relation.time_id WHERE employee_timing_relation.emp_id='$id'";
  $result = mysqli_query($conn, $query);

  return $result;
}
function get_employee_time_id_by_id($id)
{
  global $conn;
  $query = "SELECT timing.time_id FROM timing INNER JOIN employee_timing_relation ON timing.time_id = employee_timing_relation.time_id WHERE employee_timing_relation.emp_id='$id'";
  $result = mysqli_query($conn, $query);

  return $result;
}
function get_all_employee_timing_relation_data()
{
  global $conn;
  $query = "SELECT * FROM `employee_timing_relation`";
  $result = mysqli_query($conn, $query);

  return $result;
}

function get_employee_checked_time_id_from_relation_table($emp_id)
{
  global $conn;
  $query = "SELECT employee_timing_relation.time_id FROM timing INNER JOIN employee_timing_relation ON timing.time_id = employee_timing_relation.time_id WHERE employee_timing_relation.emp_id='$emp_id'";
  $result = mysqli_query($conn, $query);
  return $result;

}




function display_employee_table($cur_page)
{
  global $conn, $table_data;
  $offset = ($cur_page - 1) * LIMIT;
  $start_from = get_start_from_value_employee($cur_page);
  $sql = "SELECT * FROM employee ORDER BY emp_id DESC LIMIT " . LIMIT . " OFFSET $offset";
  $result = mysqli_query($conn, $sql);


  $n = $start_from;
  $start = 0;
  while ($row1 = mysqli_fetch_assoc($result)) { ?>

    <?php

    if ($row1['status'] == '1') {
      $class_td = "";
      $data_title = "Click to Disable";
      $btn_color = "btn btn-success";


    } else if ($row1['status'] == '0') {
      $class_td = "disable";
      $data_title = "Click to Enable";
      $btn_color = "btn btn-warning";
    }


    ?>
    <?php $table_data ?>
    <tr>

      <td class="bold <?php echo $class_td ?>" scope="row">
        <?php
        echo $n + $start;
        ?>
      </td>

      <td class="<?php echo $class_td ?>">
        <?php
        $x = $row1['fname'];
        $x1 = strtolower($x);

        $y = $row1['lname'];
        $y1 = strtolower($y);

        $dn = $x1 . ' ' . $y1;
        $dn = ucwords($dn);
        echo $dn;
        // echo $x1 . ' ' . $y1;
        ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php
        $email = $row1['email'];
        echo $email;


        ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php
        $gender = $row1['gender'];
        echo ucwords(strtolower($gender));
        ?>
      </td>

      <td class="<?php echo $class_td ?>">
        <?php
        $dob = $row1['dob'];
        echo ageCalculator($dob);


        ?>
      </td>


      <td class="<?php echo $class_td ?>">
        <?php

        $row2 = get_location_data_by_id($row1['location_id']);

        if ($row2) {
          $loc = $row2['location_name'];
          $loc = ucwords(strtolower($loc));
          echo "$loc";
        } else {
          echo "Location id  not found";
        } ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php


        $time_slots = get_employee_time_slots_by_id($row1['emp_id']);
        $temp_arr = array();
        while ($row2 = mysqli_fetch_assoc($time_slots)) {
          $temp_arr[] = ($row2['time_slot']);

        }
        $ans = implode(', ', $temp_arr);
        echo "$ans";


        ?>
      </td>

      <td class="<?php echo $class_td ?>">
        <?php
        if ($row1['status'] == '1') { ?>

          <!-- Edit Button -->
          <a href="employee_form.php?action=edit&id=<?php echo $row1['emp_id'] ?>">
            <button type="button" class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
              Edit
            </button></a>

        <?php }
        ?>
        <!-- Delete Button -->
        <button type="button" class="btn btn-danger" button style="margin-right:10px" name="employee"
          id="<?php echo $row1['emp_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
          Delete
        </button>

        <!-- Status  Button -->



        <input type="hidden" class="form-control" name="status" id="status_data" value="status">
        <button type="button" class="<?php echo $btn_color ?>" id="<?php echo $row1['emp_id'] ?>" name="employee"
          value="<?php echo $row1['status'] ?>" onclick='return updatestatus_employee(this.id, this.name, this.value)'
          data-title="<?php echo $data_title ?>">
          Status
        </button>



      </td>



    </tr>

    <?php
    $n++;

  } ?>
  <?php return $table_data;

} ?>



<?php

function get_start_from_value_employee($cur_page)
{
  $start_from = (LIMIT * ($cur_page - 1)) + 1;
  return $start_from;
}
function get_total_pages_employee()
{
  $total_rows = get_total_num_of_table_row('employee');
  $total_number_of_pages = ceil($total_rows / LIMIT);
  return $total_number_of_pages;
}

function get_location_data_by_id($id)
{
  global $conn;
  $query = "SELECT * FROM locations WHERE location_id= $id";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
    $arr['location_name'] = $row['location_name'];
    $arr['location_distance'] = $row['location_distance'];
    $arr['location_parent_id'] = $row['location_parent_id'];
    $arr['location_id'] = $row['location_id'];
    $arr['status'] = $row['status'];
    return $arr;

  }



}
function categoryTree($location_parent_id = 0, $sub_mark = '')
{

  global $conn, $selected, $employee_location_id;

  if ($_GET['action'] == "edit") {
    $id = $_GET['id'];
    $employee_data = get_employee_data_by_id($id);
    $employee_location_id = $employee_data['location_id'];
  }
  $query = "SELECT * FROM `locations` WHERE `location_parent_id`='$location_parent_id'";
  $result = mysqli_query($conn, $query);


  if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
      $selected = '';
      if ($_GET['action'] == "edit" && $employee_location_id == $row['location_id']) {
        $selected = 'selected';
      }
      ?>
      <option value="<?php echo $row['location_id']; ?>" <?php echo $selected ?>> <?php echo "$sub_mark " ?>
        <?php echo $row['location_name'] ?>
      </option>;
      <?php categoryTree($row['location_id'], $sub_mark . '---');
    }
  }


}

?>