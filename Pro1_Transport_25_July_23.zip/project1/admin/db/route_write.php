<?php
include_once("db.php");

$file = $_POST['file'];

echo $file;


if (!empty($_POST['timeperiod']) && isset($_POST['timeperiod']) && filter_var($_POST['timeperiod'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['timeperiod'])) {
    $timeperiod = $_POST['timeperiod'];
}
if (!empty($_POST['time_id']) && isset($_POST['time_id']) && filter_var($_POST['time_id'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['time_id'])) {
    $time_id = $_POST['time_id'];
}
if (!empty($_POST['location_id']) && isset($_POST['location_id']) && filter_var($_POST['location_id'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['location_id'])) {
    $location_id = $_POST['location_id'];
}
if (!empty($_POST['vehicle_id']) && isset($_POST['vehicle_id']) && filter_var($_POST['vehicle_id'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['vehicle_id'])) {
    $vehicle_id = $_POST['vehicle_id'];
}

if (isset($_POST['submit']) && !empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}


if (isset($submit)) {
    if ($submit == "Update Route") {
        $id = $_POST['uid'];
        update_route($id);
    }
    if ($submit == "Save Route") {
        insert_route();
    }

}


/*
 *Function - insert_route(): It insert the start_point, end_point, time_slot,vehicle_id field values into routes tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */


function insert_route()
{
    global $timeperiod, $time_id, $vehicle_id, $location_id, $conn;

    echo $sql = "INSERT INTO `routes`(`timeperiod`,`time_id`,`location_id`,`vehicle_id`) VALUES ('$timeperiod','$time_id','$location_id','$vehicle_id')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    // header("Location: http://practice.indianexpress.com/project1/admin/route_list.php");
}

/*
 * Function - update_employee(): It update  the  start_point, end_point, time_slot,vehicle_id field values  into routes table data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-routes .
 * Return  value: data type- void , return value - does not return any value.
 */
function update_route($id)
{
    global $timeperiod, $time_id, $vehicle_id, $location_id, $conn;




    $sql = "UPDATE `routes` SET `timeperiod`='$timeperiod',`time_id`='$time_id',`location_id`='$location_id',`vehicle_id`='$vehicle_id' WHERE `route_id`='$id'";
    // print_r($sql);
    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        echo "success";
        header("Location: http://practice.indianexpress.com/project1/admin/route_list.php");

    }

}


$id = $_GET['id'];
$status = $_GET['status'];


if ($status == 1) {
    $status = 0;
} else if ($status == 0) {
    $status = 1;
}

if (isset($id)) {
    if ($_GET['action'] == "delete") {
        delete_route($id);
    } else if ($_GET['action'] == "status") {
        update_status($id);


    }
}


/*
 *Function - delete_employee(): It delete  all the details/feilds value in routes table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-routes.
 * Return  value: data type- void , return value - does not return any value.
 */
function delete_route($id)
{
    global $conn;
    $sql = "DELETE FROM `routes` WHERE `route_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/route_list.php");

}

function update_status($id)
{
    global $conn, $status;
    $sql = "UPDATE `routes` SET status='$status' WHERE `route_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/route_list.php");

}

?>