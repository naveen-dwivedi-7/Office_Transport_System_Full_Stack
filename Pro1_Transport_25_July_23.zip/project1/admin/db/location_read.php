<?php
// Database connection file
include_once("db.php");



if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
    include_once('../templates/common.php');
    $page = 1;
    if (isset($_POST['page'])) {
        $page = $_POST['page'];
    }

    display_location_table($page);
} else {
    include_once('templates/common.php');
}




/*
 * Function -get_all_admin_data() : It fetch data from table admin_details and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- object , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */

function get_all_location_data()
{
    global $conn;
    $query = "SELECT * FROM locations";
    $result = mysqli_query($conn, $query);

    return $result;
}

/*
 *Function - get_all_admin_data_by_id(): It fetch a single row  from table admin_details  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */
function get_location_data_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM locations WHERE location_id= $id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $arr['location_name'] = $row['location_name'];
        $arr['location_distance'] = $row['location_distance'];
        $arr['location_parent_id'] = $row['location_parent_id'];
        $arr['location_id'] = $row['location_id'];
        $arr['status'] = $row['status'];
        return $arr;

    }



}


// show drop down category and sub category 
function categoryTree($location_parent_id = 0, $sub_mark = '')
{

    global $conn, $selected, $employee_location_id;

    if ($_GET['action'] == "edit") {
        $id = $_GET['id'];
        $employee_data = get_employee_data_by_id($id);
        $employee_location_id = $employee_data['location_id'];
    }
    $query = "SELECT * FROM `locations` WHERE `location_parent_id`='$location_parent_id'";
    $result = mysqli_query($conn, $query);


    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {
            $selected = '';
            if ($_GET['action'] == "edit" && $employee_location_id == $row['location_id']) {
                $selected = 'selected';
            }
            ?>
            <option value="<?php echo $row['location_id']; ?>" <?php echo $selected ?>> <?php echo "$sub_mark " ?>
                <?php echo $row['location_name'] ?>
            </option>;
            <?php categoryTree($row['location_id'], $sub_mark . '---');
        }
    }


}

function categoryTree_Route($location_parent_id = 0, $sub_mark = '')
{

    global $conn, $selected, $route_location_id;
    $id = $_GET['id'];
    $route_data = get_route_data_by_id($id);
    $route_location_id = $route_data['location_id'];

    echo "$route_location_id";


    $query = "SELECT * FROM `locations` WHERE `location_parent_id`='$location_parent_id'";
    $result = mysqli_query($conn, $query);


    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {
            $selected = '';
            if ($_GET['action'] == "edit" && $route_location_id == $row['location_id']) {
                $selected = 'selected';
            }
            ?>
            <option value="<?php echo $row['location_id']; ?>" <?php echo $selected ?>> <?php echo "$sub_mark " ?>
                <?php echo $row['location_name'] ?>
            </option>;
            <?php categoryTree_Route($row['location_id'], $sub_mark . '---');
        }
    }


}

function get_parent_id($id = 0)
{

    global $conn;
    $query = "SELECT * FROM `locations` WHERE `location_parent_id`='$id'";
    $result = mysqli_query($conn, $query);
    return $result;

}


function get_parent_name_by_id($id)
{
    global $conn;
    if ($id == 0) {

        $arr['location_name'] = "No Parent";

        return $arr;


    } else if ($id != 0) {
        $query = "SELECT `location_name` FROM `locations` WHERE `location_id`='$id'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_array($result);
            $arr['location_name'] = $row['location_name'];

            return $arr;

        }

    }

}

function get_location_name_data_by_location_id($id)
{
    global $conn;
    $query = "SELECT `location_name` FROM locations WHERE `location_id`= '$id'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $arr['location_name'] = $row['location_name'];


        return $arr;

    }



}

function display_location_table($cur_page)
{
    global $conn, $table_data;
    $offset = ($cur_page - 1) * LIMIT;
    $start_from = get_start_from_value_location($cur_page);
    $sql = "SELECT * FROM locations ORDER BY location_id DESC LIMIT " . LIMIT . " OFFSET $offset";
    $result = mysqli_query($conn, $sql);


    $n = $start_from;
    $start = 0;

    while ($row1 = mysqli_fetch_assoc($result)) { ?>

<?php

                if ($row1['status'] == '1') {
                    $class_td = "";
                    $data_title = "Click to Disable";
                    $btn_color = "btn btn-success";


                } else if ($row1['status'] == '0') {
                    $class_td = "disable";
                    $data_title = "Click to Enable";
                    $btn_color = "btn btn-warning";
                }
                ?>
        <?php $table_data ?>
        <tr>
            <td class="<?php echo $class_td ?> bold" scope="row">
        <?php echo $n + $start; ?>
        </td>
        <td class="<?php echo $class_td ?>">
        <?php $loc = $row1['location_name'];
        $loc = ucwords(strtolower($loc));
        echo "$loc"; ?>
        </td>

        <td class="<?php echo $class_td ?>">
        <?php
        $location_names = get_parent_name_by_id($row1['location_parent_id']);
        echo $location_names['location_name'];

        ?>
        </td>
        <td class="<?php echo $class_td ?>">
        <?php echo $row1['location_distance'] ?>
        </td>

        <td class="<?php echo $class_td ?>">

        <?php if ($row1['status'] == '1') { ?>
            <!-- Edit Button -->

            <a href="location_form.php?action=edit&id=<?php echo "$row1[location_id] " ?>"> <button type=" button"
                    class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
                    Edit
                </button></a>
        <?php } ?>
        <!-- Delete Button -->
        <button type="button" class="btn btn-danger" button style="margin-right:10px" name="location"
            id="<?php echo $row1['location_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
            Delete
        </button>

        <!-- Status  Button -->

        <input type="hidden" class="form-control" name="status" id="status_data" value="status">
        <button type="button" class="<?php echo $btn_color ?>" id="<?php echo $row1['location_id'] ?>" name="location"
            value="<?php echo $row1['status'] ?>" onclick='return updatestatus_location(this.id, this.name, this.value)'
            data-title="<?php echo $data_title ?>">
            Status
        </button>


    </td>
    <?php } ?>

    </tr>


<?php
        $n++;
        return $table_data;

} ?>

<?php
function get_start_from_value_location($cur_page)
{
    $start_from = (LIMIT * ($cur_page - 1)) + 1;
    return $start_from;
}

function get_total_pages_location()
{
    $total_rows = get_total_num_of_table_row('locations');
    $total_number_of_pages = ceil($total_rows / LIMIT);
    return $total_number_of_pages;
}
?>