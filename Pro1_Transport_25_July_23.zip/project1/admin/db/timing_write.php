<?php
include_once("db.php");



$file = $_POST['file'];

echo $file;

if (isset($_POST['time_slot']) && !empty($_POST['time_slot']) && filter_var($_POST['time_slot'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['time_slot'])) {
    $time_slot = $_POST['time_slot'];
}


if (stripos($time_slot, 'pm')) {
    $timeperiod = 'E';

} else {
    $timeperiod = 'M';
}
if (!empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}



if (isset($submit)) {
    if ($submit == "Update Timing") {
        $id = $_POST['uid'];
        update_timing($id);
    }
    if ($submit == "Save Timing") {
        insert_timing();
    }

}

/*
 *Function - insert_timing(): It insert the time_slot field into timing  tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */


function insert_timing()
{
    global $time_slot, $timeperiod, $conn;
    $sql = "INSERT INTO `timing`(`time_slot`,`timeperiod`) VALUES ('$time_slot','$timeperiod')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    // header("Location: http://practice.indianexpress.com/project1/admin/timing_form_list.php?action=add");
}



/*
 * Function - update_timing(): It update  time_slot field into timing table data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table- timing  .
 * Return  value: data type- void , return value - does not return any value.
 */
function update_timing($id)
{
    global $time_slot, $timeperiod, $conn;
    $sql = "UPDATE `timing` SET `time_slot`='$time_slot',`timeperiod`='$timeperiod' WHERE `time_id`='$id'";
    print_r($sql);
    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        echo "success";
        header("Location: http://practice.indianexpress.com/project1/admin/timing_form_list.php?action=add");

    }

}


$id = $_GET['id'];
$status = $_GET['status'];


if ($status == 1) {
    $status = 0;
} else if ($status == 0) {
    $status = 1;
}

if (isset($id)) {
    if ($_GET['action'] == "delete") {
        delete_timing($id);
    } else if ($_GET['action'] == "status") {
        update_status($id);


    }
}
/*
 *Function - delete_employee(): It delete  all the details/fields values in timing table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-timing.
 * Return  value: data type- void , return value - does not return any value.
 */
function delete_timing($id)
{
    global $conn;
    $sql = "DELETE FROM `timing` WHERE `time_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/timing_form_list.php?action=add");

}

function update_status($id)
{
    global $conn, $status;
    $sql = "UPDATE `timing` SET status='$status' WHERE `time_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/timing_form_list.php");

}

?>