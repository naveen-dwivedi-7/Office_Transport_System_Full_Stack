<?php
include_once('db.php');


function get_employee_data_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM employee WHERE emp_id= $id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // output data of each row}
        $row = mysqli_fetch_array($result);
        $arr['fname'] = $row['fname'];
        $arr['lname'] = $row['lname'];
        $arr['email'] = $row['email'];
        $arr['gender'] = $row['gender'];
        $arr['dob'] = $row['dob'];
        $arr['emp_profile'] = $row['emp_profile'];
        $arr['location_id'] = $row['location_id'];
        $arr['status'] = $row['status'];

        return $arr;

    }



}