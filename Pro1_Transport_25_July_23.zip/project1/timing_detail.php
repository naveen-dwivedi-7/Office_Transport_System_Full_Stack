<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>
<?php
if (isset($_GET['timeperiod'])) {
    $tperiod = $_GET['timeperiod'];
}

if (isset($_GET['time_id']) && !empty($_GET['time_id'])) {
    $time_id = $_GET['time_id'];
    $clicked_time_id = $time_id;
}
?>
<?php



$timeSlot = get_time_slot_by_time_id($clicked_time_id);



?>
<div class="content">
    <div class="content-left">
        <h1 class="title">Route Details for Time:<span>
                <?php echo "$timeSlot" ?>
            </span></h1>


        <p>


            <?php

            $res = get_all_location_id_vehicle_id_by_time_id($clicked_time_id); ?>

        <div class="row1">


            <?php if (mysqli_num_rows($res) > 0) { ?>

                <?php $i = 1 ?>


                <?php while ($row = mysqli_fetch_assoc($res)) { ?>





                    <h2>
                        <?php
                        echo "Route$i:";
                        $loc_name = get_location_name_by_location_id($row['location_id']);
                        $loc_name = strtolower($loc_name);
                        $loc_name = ucfirst($loc_name);
                        if ($tperiod == 'M') {
                            echo " From $loc_name to office ";
                        }
                        if ($tperiod == 'E') {
                            echo " From  office to $loc_name ";
                        }

                        ?>
                    </h2>
                    <ul class="list1">

                        <li>
                            <?php $area = get_parent_area_by_location_id($row['location_id']);
                            echo "Area: $area " ?>
                        </li>

                        <li>
                            <?php $distance = get_location_distance_by_location_id($row['location_id']); ?>
                            <?php echo "Distance : $distance Km "; ?>
                        </li>



                        <?php $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']); ?>


                        <li>
                            <?php echo "Vehicle:$data[model]" ?>
                        </li>

                        <li>
                            <?php echo "Capacity:$data[capacity]" ?>
                        </li>
                        <?php $route_id = $row['route_id'];

                        ?>

                        <p><a href="book_route.php?r_id=<?php echo $route_id ?>" class="more">Book Route
                                <?php echo $i ?>
                            </a></p>
                        <?php $i++; ?>
                    </ul>

                <?php }
            } ?>

        </div>



        </p>
        <p>&nbsp;</p>
        <!-- <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p> -->
        <!-- <p><a href="#" class="more">Read More</a></p>


        <div class="row1">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the indusstandard dummy
                text ever since the 1500s, when an unknown printer took a galley of
                type and scrambleto make a type specimen book.</p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy textof the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
            <p><a href="#" class="more">Read More</a></p>
        </div> -->
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>