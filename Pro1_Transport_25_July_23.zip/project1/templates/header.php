<?php ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Project1 Transport</title>
    <meta name="description" content="Description of your site goes here">
    <meta name="keywords" content="keyword1, keyword2, keyword3">

    <link href="css/style.css?adiha7787bbdb87ww" rel="stylesheet" type="text/css">
</head>

<body>
    <div class="page-in">
        <div class="page">
            <div class="main">
                <div class="header">
                    <div class="header-top">
                        <h1> <span></span></h1>
                    </div>
                    <div class="header-bottom">
                        <h2>Office Transport<br>
                            Management System</h2>
                    </div>
                    <div class="topmenu">
                        <ul>
                            <li
                                style="background: transparent none repeat scroll 0% 50%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial; padding-left: 0px;">
                                <a href="index.php"><span>Home</span></a>
                            </li>
                            <li><a href="morning_routes.php"><span>Morning&nbsp;Routes</span></a></li>
                            <li><a href="evening_routes.php"><span>Evening Routes</span></a>
                            </li>
                            <li><a href="book_route.php"><span>Book
                                        &nbsp;Route</span></a></li>

                            <li><a href="timing_list.php"><span>Timings</span></a>
                            </li>

                            <li><a href="register_form.php"><span>Register here</span></a>
                            </li>
                        </ul>
                    </div>
                </div>