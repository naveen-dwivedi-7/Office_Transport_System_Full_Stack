<div class="content-right">
    <div class="mainmenu">
        <h2 class="sidebar1">Location Areas</h2>
        <ul>
            <?php
            include_once('./db_frontend_read.php');
            $res = get_parent_area_names();
            while ($row = mysqli_fetch_assoc($res)) { ?>
                <li>
                    <?php echo $row['location_name'] ?>
                </li>

            <?php } ?>
            <!-- <li><a href="#">this is a dummy link 1</a></li>
            <li><a href="#">this is a dummy link 2</a></li>
            <li><a href="#">this is a dummy link 3</a></li>
            <li><a href="#">this is a dummy link 4</a></li>
            <li><a href="#">this is a dummy link 5</a></li>
            <li><a href="#">this is a dummy link 6</a></li>
            <li><a href="#">this is a dummy link 7</a></li>
            <li><a href="#">this is a dummy link 8</a></li>
            <li><a href="#">this is a dummy link 9</a></li>
            <li><a href="#">this is a dummy link 10</a></li> -->
        </ul>
    </div>
    <div class="contact">
        <h2 class="sidebar2">Contact Us </h2>
        <div class="contact-detail">

            <!-- <p class="name">
                <input type="text" name="name" id="name" placeholder="Enter your name">
                <label for="name">Name</label>
            </p>

            <p class="email">
                <input type="text" name="email" id="email" placeholder="mail@example.com">
                <label for="email">Email</label>
            </p>

            <p class="mobile">
                <input type="text" name="mobile" id="mobile" placeholder="mobile no.">
                <label for="mobile">Phone Number</label>
            </p>

            <p class="message">
                <textarea name="text" placeholder="Write something to us"></textarea>
                <label for="text">Message</label>
            </p>

            <p class="submit">
                <input type="submit" name="submit" value="Send">
            </p>
            </form> -->
            <p class="green"><strong> The indian Express Group</strong></p>
            <p><strong>Adress :</strong> B1, Sector 10, Noida<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Uttar
                Pradesh ,India</p>
            <p><strong>E-mail :</strong> &nbsp;&nbsp;&nbsp;theindianexpress@gmail.com</p>
            <p><strong>Phone :</strong> &nbsp;&nbsp;&nbsp;91-0000000000<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </p>
            <p><strong>For any queries feel free to fill the form</strong>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
            <p class="green"> <strong> <a href="contact_form.php"><span>Send&nbsp;Your Queries</span></a><strong></p>
        </div>

    </div>
</div>