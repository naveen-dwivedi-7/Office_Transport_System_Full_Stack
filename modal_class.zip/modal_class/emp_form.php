<?php 

?>

<!DOCTYPE html>
<html>
<head>
<title>Form</title>
<link href="css/insert.css" rel="stylesheet">
</head>
<body>
<div class="maindiv">
<!--HTML Form -->
<div class="form_div">
<div class="title">
<h2>Enter Employee Details:</h2>
</div>
<form action="modal_write.php" method="post">
<!-- Method can be set as POST for hiding values in URL-->
<h2>Form</h2>

<label>Enter name:</label><br>
<input class="input" name="name" type="text" ><br>
<label>Email</label><br>
<input class="input" name="email" type="text" >

<p>Please Select Your Gender:</p>
<input type="radio" id="male" name="gender" value="M">
  <label for="male">Male</label>
  <input type="radio" id="female" name="gender" value="F">
  <label for="female">Female</label><br>
<input class="submit" name="submit" type="submit" value="Insert">
</form>
</div>
</div>
</body>
</html>