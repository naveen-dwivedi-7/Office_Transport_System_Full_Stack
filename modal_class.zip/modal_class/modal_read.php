<?php
include_once('db.php');

function get_all_employee_data_by_id($id){
    global $conn;
    $sql="SELECT `emp_id`, `name`, `email`, `gender` FROM `employee` WHERE emp_id='$id'";
    $result=mysqli_query($conn, $sql);
     if(mysqli_num_rows($result)==1){
           return $result;
       
    }else{  
       return 0;  
       } 



}
function get_employee_name_by_id($id){
    global $conn;
    $sql="SELECT `emp_id`, `name` FROM `employee` WHERE emp_id='$id'";
    $result=mysqli_query($conn, $sql);
     if(mysqli_num_rows($result)==1){
           return $result;
       
    }else{  
       return 0;  
       } 

       

}