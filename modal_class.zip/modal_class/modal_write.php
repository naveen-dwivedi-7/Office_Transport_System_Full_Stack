<?php
include_once('db.php');
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
}

insert();
function insert(){
    global $conn, $name,$email, $gender;
    $sql="INSERT INTO `employee`( `name`, `email`, `gender`) VALUES ('$name','$email','$gender')";
    if(mysqli_query($conn, $sql)){  

        echo "Record inserted successfully";  
       
       }else{  
       
       echo "Could not insert record: ". mysqli_error($conn);  
       
       } 

}
