<?php

?>
<div class="content">
    <!-- <div class="content-left">
        <div class="row1">
            <h1 class="title">Welcome To <span>Our Site</span></h1>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the indusstandard dummy
                text ever since the 1500s, when an unknown printer took a galley of
                type and scrambleto make a type specimen book.</p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                <strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
        </div>
        <div class="row2">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the aaaa industry's
                standard dummy text ever since the 1500s, ass as dwhen an unknasdown
                printer took a galley of type and scrambled it to make a type
                speascimen book. <br>
                It has survived not only five centuries, but also the leap into
                electronic typesetting.and scrambled it to make a type speascimen book.</p>
            <p>&nbsp;</p>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.</p>
            <p>&nbsp;</p>
            <p align="right"><a href="#" class="more">Read More</a></p>
        </div> -->




</div>