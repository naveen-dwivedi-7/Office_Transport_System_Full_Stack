<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>
<div class="content">
    <div class="content-left">
        <h1 class="title">Routes <span>in Evening </span></h1>

        <!-- <h2 class="subtitle">Morning <span>Routes From</span></h2> -->
        <p>
            <?php

            $res = get_all_route_evening_data(); ?>

            <?php if (mysqli_num_rows($res) > 0) { ?>
            <div class="row1">
                <?php while ($row = mysqli_fetch_assoc($res)) { ?>

                    <?php
                    $loc_id = $row['location_id'];
                    $location = get_location_name_by_location_id($row['location_id']);
                    if (empty($location)) {
                        $location = "Data Not Found";
                    } ?>
                    <h2>From
                        <?php echo " office to " ?>
                        <a style="text-decoration: none"
                            href="http://practice.indianexpress.com/project1/location_detail.php?loc_id=<?php echo $loc_id ?>">
                            <?php echo "$location" ?>
                        </a>
                    </h2>
                    <?php
                    $timeslot = get_time_slot_by_time_id($row['time_id']);
                    $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']);
                    $model = $data['model'];
                    $capacity = $data['capacity'];
                    $distance = get_location_distance_by_location_id($row['location_id']);
                    if (empty($distance)) {
                        $distance = "Data Not Found";
                    } ?>

                    <ul class="list1">

                        <li>
                            <?php echo "Distance: $distance Km" ?>
                        </li>
                        <li>
                            <?php echo "Time: $timeslot" ?>
                        </li>
                        <li>
                            <?php echo " Vehicle: $model " ?>
                        </li>
                        <li>
                            <?php echo "Capacity: $capacity " ?>
                        </li>
                        <?php $route_id = $row['route_id'];

                        ?>
                        <p><a href="book_route.php?r_id=<?php echo $route_id ?>" class="more">Book Route

                            </a></p>
                    </ul>
                <?php } ?>
            </div>
        <?php } ?>





        </p>
        <p>&nbsp;</p>
        <!-- <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p> -->
        <!-- <p><a href="#" class="more">Read More</a></p>


        <div class="row1">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the indusstandard dummy
                text ever since the 1500s, when an unknown printer took a galley of
                type and scrambleto make a type specimen book.</p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy textof the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
            <p><a href="#" class="more">Read More</a></p>
        </div> -->
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>