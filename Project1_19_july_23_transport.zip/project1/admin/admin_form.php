<?php
$page_name = 'Admin Form Page';
include_once('templates/header.php');
include_once("db/admin_read.php");


$action = $_GET['action'];
if (isset($action)) {
    if ($action == "edit") {
        $uid = $_GET['id'];

        $data = get_admin_data_by_id($uid);

        $name = $data['name'];
        $email = $data['email'];
        $username = $data['username'];
        $password = $data['password'];
        $user_role = $data['user_role'];
        $status = $data['status'];
        $var = "Update Admin";

    } elseif ($action == "add") {
        $name = "";
        $email = "";
        $username = "";
        $password = "";
        $user_role = "";
        $status = "1";
        $var = "Save Admin";

    }

}


?>

<body>
    <div id="disp1"></div>
    <div class="container mt-3">
        <div id="err"></div><!-- View Errors -->
        <h2>Enter Admin Details</h2>
        <form id="admin_form">

            <div class="mb-3 mt-3">
                <label for="name">Name</label>
                <input type="hidden" class="form-control" name="uid" id="uid_data" value="<?php echo $uid ?>">
                <input type="name" class="form-control" placeholder="Enter Your Display name" name="name" id="name_data"
                    value="<?php echo $name ?>">

            </div>
            <div class="mb-3 mt-3">
                <label for="email">Email:</label>
                <input type="email" class="form-control" placeholder="Enter email" name="email" id="email_data"
                    value="<?php echo $email ?>">
                <?php
                if (isset($_GET['msg'])) {
                    echo "<div class='alert alert-danger'>
                $_GET[msg]
               </div>";
                } else {
                    echo '';
                }
                ?>
            </div>
            <div class="mb-3 mt-3">
                <label for="username">Username:</label>
                <input type="username" class="form-control" placeholder="Enter Username" name="username"
                    id="username_data" value="<?php echo $username ?>">
                <?php
                if (isset($_GET['msg1'])) {
                    echo "<div class='alert alert-danger'>
                $_GET[msg1]
               </div>";
                } else {
                    echo '';
                }
                ?>
            </div>
            <div class="mb-3">
                <label for="password">Password:</label>
                <input type="password" class="form-control" placeholder="Enter password" name="password"
                    id="password_data" value="<?php echo $password
                        ?>">
            </div>

            <div class="mb-3 mt-3">
                <label for="user_role">User Role:</label>
                <input type="radio" name="user_role" value="admin" <?php echo ($user_role == 'admin') ? "CHECKED" : " " ?> />Admin
                <input type="radio" name="user_role" value="super_admin" <?php echo ($user_role == 'super_admin') ? "CHECKED" : " " ?> />Super Admin
            </div>


            <div class="mb-3 mt-3">
                <label for="status">Admin Status:</label>
                <input type="radio" name="status" value="1" <?php echo ($status == '1') ? "CHECKED" : " " ?> />Enabled

                <input type="radio" name="status" value="0" <?php echo ($status == '0') ? "CHECKED" : " " ?> />Disabled
            </div>

            <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
            <input type="submit" class="btn btn-primary" name="submit_button" id="submit_button"
                value="<?php echo $var; ?>">


            </a>

        </form>
        <br>
        <a href='http://practice.indianexpress.com/project1/admin/admin_list.php'>
            <button class="btn btn-dark">
                Show Admin List
            </button>
    </div>

</body>



<?php include('templates/footer.php'); ?>