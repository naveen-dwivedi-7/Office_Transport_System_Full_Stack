<?php
include_once('./db/db.php');
session_start();

if (!isset($_SESSION['admin_name'])) {
    header("Location: http://practice.indianexpress.com/project1/admin/");
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>IE Project Office Transport</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css?ver=<?php echo $version ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css"
        rel="stylesheet" />


</head>
<header>
    <?php if ("Login Page" !== $page_name) { ?>
        <nav class="navbar navbar-expand-lg navbar-light bg-white">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarExample01"
                    aria-controls="navbarExample01" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarExample01">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">



                        <li class="nav-item">
                            <a class="nav-link" href="employee_list.php">Employee</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="timing_form_list.php?action=add">Timing</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="vehicle_list.php">Vehicle</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="route_list.php">Routes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="location_list.php">Locations</a>
                        </li>
                        <?php
                        if ($_SESSION['user_role'] == "super_admin") {

                            ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin_list.php">Admin </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact_list.php">Enquiries </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="request_routes_list.php">Request Routes </a>
                            </li>

                            <?php
                        } ?>

                        <li class="nav-item ">
                            <a class="nav-link " href="logout.php">Logout
                            </a>
                        </li>
                        <div>
                            <li class="nav-item col-md-2" style="margin-left : 700px;">
                                <a class="nav-link" href="profile.php"> Welcome
                                    <?php

                                    echo ($_SESSION['admin_name']) ?>

                                </a>
                            </li>



                    </ul>
                </div>
            </div>
        </nav>
    <?php } ?>
    <div class="p-5 text-center bg-light">
        <h1 class="mb-3">Office Transport System</h1>
        <h4 class="mb-3">
            <?php echo $page_name; ?>
        </h4>
    </div>
</header>