<?php

include_once("db/request_routes_read.php");
$page_name = 'Enquiry List Page';
include_once('templates/header.php');



$start_from = get_start_from_value_request($cur_page);
$total_number_of_pages = get_total_pages_request();


?>

<body>

    <div class="container-xl">
        <br>


        <div class="col-md-12">
            <br>

            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Requested Routes</th>
                        <th scope="col">Requested Employees</th>
                        <th scope="col">Filling capacity</th>
                        <th scope="col">Requested Date</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="request_routes_read.php">

                    <?php display_request_table($cur_page); ?>



                </tbody>
            </table>
        </div>

        <?php
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>