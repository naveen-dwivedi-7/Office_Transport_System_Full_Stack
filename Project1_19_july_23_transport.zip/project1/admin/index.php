<?php
session_start();

if (isset($_SESSION['admin_name'])) {
    header("Location: http://practice.indianexpress.com/project1/admin/profile.php");
}

?>
<?php
$page_name = 'Login Page';
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<style>
    body {
        background-color: #f2f2f2;
    }

    .container {
        max-width: 400px;
        margin: 0 auto;
        padding: 50px 20px;
    }

    .login-container {
        background-color: #ffffff;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        padding: 40px;
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
    }

    .form-group label {
        font-weight: bold;
        color: #666666;
    }

    .form-control {
        border-radius: 4px;
    }

    .form-control:focus {
        border-color: #4caf50;
        box-shadow: none;
    }

    .login-btn {
        background-color: blue;
        color: #ffffff;
        border: none;
        border-radius: 4px;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .login-btn:hover {
        background-color: #45a049;
    }
</style>

<body>

    <div class="container">
        <div class="login-container">
            <h1 style="text-align: center; ">Login in to admin account</h1>
            <br>
            <form id="login" name="login" action="db/login_write.php" method="POST">
                <div class="form-group">
                    <label class="required" for="username">
                        Username
                    </label>
                    <input type="text" class="form-control" placeholder="Enter Username" name="username" id="username">
                </div>
                <br>
                <div class="form-group">
                    <label class="required" for="password">
                        Password
                    </label>
                    <input type="password" class="form-control" placeholder="Enter Password" name="password"
                        id="password">
                </div>
                <br>
                <div class="form-group">
                    <input type="submit" class="login-btn" name="login" value="login">
                </div>
            </form>



            <?php
            if (isset($_GET['msg'])) {
                echo "<div class='alert alert-danger'>
                $_GET[msg]
               </div>";
            } else {
                echo '';
            }
            ?>





        </div>
    </div>
    <br>
    <div>




</body>

</div>
<?php
include_once('templates/footer.php');
?>


<script>
    //  validating form script

    $().ready(function () {

        $("#login").validate({


            rules: {


                username: {
                    required: true,
                    minlength: 3
                },

                password: {
                    required: true,
                    minlength: 5
                }




            },

            messages: {

                username: {
                    required: " Please enter a username name",
                    minlength: " Your username must consist of at least 3 characters"
                },

                password: {
                    required: " Please enter a password",
                    minlength: " Your password must be consist of at least 5 characters"
                }


            }
        })

    });
</script>