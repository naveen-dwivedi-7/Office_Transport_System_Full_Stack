<?php
$page_name = 'Vehicle List Page';
include_once('templates/header.php');
include_once("db/vehicle_read.php");
include_once("templates/common.php");




$start_from = get_start_from_value_vehicle($cur_page);
$total_number_of_pages = get_total_pages_vehicle();



?>

<body>
    <div class="container-xl">
        <br>
        <a href="/project1/admin/vehicle_form.php?action=add">
            <button type="button" class="btn btn-primary btn-lg" name="add" value="add">
                Add New Vehicle
            </button>
        </a>
        <div class="col-md-12">
            <br>
            <?php $n = 1; ?>
            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Vehicle No</th>
                        <th scope="col">Model</th>
                        <th scope="col">Capacity</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="vehicle_read.php">

                    <?php display_vehicle_table($cur_page); ?>



                </tbody>
            </table>

        </div>
        <?php
        pagination_links($total_number_of_pages);
        ?>
    </div>
</body>

<?php
include_once('templates/footer.php');
?>

<script>
    function checkdelete() {

        return confirm("Are you sure you want to delete this record");
    }
</script>