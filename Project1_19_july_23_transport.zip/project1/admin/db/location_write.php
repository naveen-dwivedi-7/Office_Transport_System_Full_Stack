<?php
include_once("db.php");


/*
 values from form submitted by user to store in different variables
*/


// $file = $_POST['file'];

// echo $file;

if (!empty($_POST['location_name']) && isset($_POST['location_name']) && filter_var($_POST['location_name'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['location_name'])) {
    $location_name = $_POST['location_name'];
}
if (!empty($_POST['location_distance']) && isset($_POST['location_distance']) && filter_var($_POST['location_distance'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['location_distance'])) {
    $location_distance = $_POST['location_distance'];
}
$location_parent_id = $_POST['location_parent_id'];

// if (!empty($_POST['location_parent_id']) && isset($_POST['location_parent_id'])) {
//     $location_parent_id = $_POST['location_parent_id'];
// }

if (!empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}

if (isset($submit)) {
    if ($submit == "Update Location") {
        $id = $_POST['uid'];
        update_location($id);
    }
    if ($submit == "Save Location") {

        insert_location();
    }

}


/*
 *Function - insert_admin(): It insert the admin_name, email, password, user_role  fields  values into admin_details tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */

function insert_location()
{
    global $location_name, $location_distance, $location_parent_id, $conn;
    $sql = "INSERT INTO `locations`( `location_name`, `location_distance`, `location_parent_id`) VALUES ('$location_name','$location_distance','$location_parent_id')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    //     header("Location: http://practice.indianexpress.com/project1/admin/location_list.php");
}


/*
 *Function - update_admin(): It update  the admin_name, email, password, user_role fields values  into admin_details tables  data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- void , return value - does not return any value.
 */


function update_location($id)
{
    global $location_name, $location_distance, $location_parent_id, $conn;



    $sql = "UPDATE `locations` SET `location_name`='$location_name',`location_distance`='$location_distance',`location_parent_id`='$location_parent_id' WHERE `location_id`='$id'";

    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        echo "success";
        header("Location: http://practice.indianexpress.com/project1/admin/location_list.php");

    }

}


$id = $_GET['id'];
$status = $_GET['status'];


if ($status == 1) {
    $status = 0;
} else if ($status == 0) {
    $status = 1;
}

if (isset($id)) {
    if ($_GET['action'] == "delete") {
        delete_location($id);
    } else if ($_GET['action'] == "status") {
        update_status($id);


    }
}
/*
 *Function - delete_admin(): It delete  all the details/field values in admin details table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- void , return value - does not return any value.
 */
function delete_location($id)
{
    global $conn;
    $sql = "DELETE FROM `locations` WHERE `location_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/location_list.php");

}

function update_status($id)
{
    global $conn, $status;
    $sql = "UPDATE `locations` SET status='$status' WHERE `location_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/location_list.php");

}


?>