<?php
include("db.php");
function no_of_email_already_in_employee_table($email)
{
    global $conn;
    $sql_email_check = "SELECT * FROM employee WHERE email='$email'";
    $result_email = mysqli_query($conn, $sql_email_check);
    $num_emails = mysqli_num_rows($result_email);
    return $num_emails;
}
function get_employee_id_by_email($email)
{
    global $conn;
    $query = "SELECT `emp_id` FROM `employee` WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $emp_id = $row['emp_id'];
        return $emp_id;

    }



}
//SELECT  `vehicle_id` FROM `routes` WHERE route_id=18
//SELECT `capacity` FROM `vehicle` WHERE vehicle_id=4
function get_vehicle_id_by_route_id($id)
{
    global $conn;
    $query = "SELECT `vehicle_id` FROM `routes` WHERE route_id='$id'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $veh_id = $row['vehicle_id'];
        return $veh_id;

    }


}
function get_capacity_by_route_id($id)
{
    global $conn;
    $vehid = get_vehicle_id_by_route_id($id);
    $query = "SELECT `capacity` FROM `vehicle` WHERE vehicle_id='$vehid'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $capacity = $row['capacity'];
        return $capacity;

    }

}
// echo get_capacity_by_route_id(18);
//SELECT COUNT(`route_id`) AS booked_routes FROM `route_employee_relation` WHERE route_id=47;
function get_no_of_booked_route($id)
{
    global $conn;
    $query = "SELECT COUNT(`route_id`) AS booked_routes FROM `route_employee_relation` WHERE route_id='$id' AND status='1'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $no_of_booked_route = $row['booked_routes'];
        return $no_of_booked_route;

    }

}
// echo get_no_of_booked_route(47);
?>