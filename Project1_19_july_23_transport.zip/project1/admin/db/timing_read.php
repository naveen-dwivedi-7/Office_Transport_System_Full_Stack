<?php
include_once("db.php");

if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
  include_once('../templates/common.php');
  $page = 1;
  if (isset($_POST['page'])) {
    $page = $_POST['page'];
  }

  display_timing_table($page);
} else {
  include_once('templates/common.php');
}

/*
 * Function -get_all_timings_data() : It fetch data from table timing and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- object , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */

function get_all_timing_data()
{
  global $conn;
  $query = "SELECT * FROM `timing` ";
  // FETCHING DATA FROM DATABASE
  $result = mysqli_query($conn, $query);

  return $result;
}

/*
 *Function - get_all_timing_data_by_id(): It fetch a single row  from table  timing  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-timing.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */

function get_timing_data_by_id($id)
{
  global $conn;
  $query = "SELECT `time_slot`,`timeperiod` FROM `timing` WHERE `time_id`='$id'";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['time_slot'] = $row['time_slot'];
    $arr['timeperiod'] = $row['timeperiod'];


    return $arr;

  }



}
function get_timing_info($id)
{
  global $conn;
  $query = "SELECT  `time_id`, `time_slot`  FROM `timing` WHERE `time_id`='$id'";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['time_id'] = $row['time_id'];
    $arr['time_slot'] = $row['time_slot'];

    return $arr;

  }

}

function get_time_slot_by_timeperiod($timeperiod)
{
  global $conn;
  $query = "SELECT  `time_id`, `time_slot`  FROM `timing` WHERE `timeperiod`='$timeperiod'";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['time_id'] = $row['time_id'];
    $arr['time_slot'] = $row['time_slot'];

    return $arr;

  }

}

function display_timing_table($cur_page)
{
  global $conn, $table_data;
  $offset = ($cur_page - 1) * LIMIT;
  $start_from = get_start_from_value_timing($cur_page);
  $sql = "SELECT * FROM timing ORDER BY time_id DESC LIMIT " . LIMIT . " OFFSET $offset";
  $result = mysqli_query($conn, $sql);




  $n = $start_from;
  $start = 0;
  while ($row1 = mysqli_fetch_assoc($result)) { ?>
    <tr>
      <?php $table_data ?>
      <?php if ($row1['status'] == 0) { ?>
        <td class='disable bold' scope="row">
          <?php echo $n + $start ?>
        </td>
        <td class='disable'>
          <?php echo $row1['time_slot'] ?>
        </td>
        <td class='disable'>
          <?php if ($row1['timeperiod'] == 'M') {
            echo "Morning";
          } else {

            echo "Evening";
          } ?>
        </td>



        <td class='disable'>


          <!-- Delete Button -->
          <button type="button" class="btn btn-danger" button style="margin-right:10px" name="timing"
            id="<?php echo $row1['time_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
            Delete
          </button>
          <!-- Status  Button -->
          <?php


          if ($row1['status'] == 1) { ?>
            <input type="hidden" class="form-control" name="status" id="status_data" value="status">
            <button type="button" class="btn btn-success" id="<?php echo $row1['time_id'] ?>" name="timing"
              value="<?php echo $row1['status'] ?>" onclick='return updatestatus_timing(this.id, this.name, this.value)'
              data-title="Click to Disable">
              Status
            </button>
          <?php } else if ($row1['status'] == 0) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-warning" id="<?php echo $row1['time_id'] ?>" name="timing"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_timing(this.id, this.name, this.value)'
                data-title="Click to Enable">
                Status
              </button>
            <?php }
          ?>

        <?php } else if ($row1['status'] == 1) { ?>
          <td class='bold' scope="row">
          <?php echo $n + $start; ?>
          </td>
          <td>
          <?php echo $row1['time_slot'] ?>
          </td>
          <td>
          <?php if ($row1['timeperiod'] == 'M') {
            echo "Morning";
          } else {

            echo "Evening";
          } ?>
          </td>



          <td>
            <!-- Edit Button -->
            <a href="timing_form_list.php?action=edit&id=<?php echo "$row1[time_id]" ?>">
              <button type="button" class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
                Edit
              </button></a>

            <!-- Delete Button -->
            <button type="button" class="btn btn-danger" button style="margin-right:10px" name="timing"
              id="<?php echo $row1['time_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
              Delete
            </button>
            <!-- Status  Button -->
            <?php


            if ($row1['status'] == 1) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-success" id="<?php echo $row1['time_id'] ?>" name="timing"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_timing(this.id, this.name, this.value)'
                data-title="Click to Disable">
                Status
              </button>
            <?php } else if ($row1['status'] == 0) { ?>
                <input type="hidden" class="form-control" name="status" id="status_data" value="status">
                <button type="button" class="btn btn-success" id="<?php echo $row1['time_id'] ?>" name="timing"
                  value="<?php echo $row1['status'] ?>" onclick='return updatestatus_timing(this.id, this.name, this.value)'
                  data-title="Click to Enable">
                  Status
                </button>
              <?php }
            ?>
          <?php } ?>
      </td>

    </tr>

    <?php $n++;
  } ?>

<?php return $table_data;

} ?>

<?php
function get_start_from_value_timing($cur_page)
{
  $start_from = (LIMIT * ($cur_page - 1)) + 1;
  return $start_from;
}

function get_total_pages_timing()
{
  $total_rows = get_total_num_of_table_row('timing');
  $total_number_of_pages = ceil($total_rows / LIMIT);
  return $total_number_of_pages;
}
?>