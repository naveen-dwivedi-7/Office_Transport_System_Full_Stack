<?php
include 'db.php';
include_once('../templates/common.php');
global $msg, $msg1;
$msg = "Sorry... email is already taken";
$msg1 = "Sorry... username is already taken";

if (isset($_GET['id'])) {
    if ($_GET['action'] == "delete") {
        $id = $_GET['id'];
        delete_admin($id);
    } else if ($_GET['action'] == "status") {



        update_status($_GET['id']);


    }
}


//validating post values from form
if (isset($_POST['name']) && !empty($_POST['name']) && mysqli_real_escape_string($conn, $_POST['name'])) {
    $name = $_POST['name'];
}
if (!empty($_POST['email']) && isset($_POST['email']) && mysqli_real_escape_string($conn, $_POST['email'])) {
    $email = $_POST['email'];
}
if (!checkspace($_POST['username']) && isset($_POST['username']) && mysqli_real_escape_string($conn, $_POST['username'])) {
    $username = $_POST['username'];
}
if ((checkspace($_POST['username']) == true)) {
    echo "invalid username ! user name contain spaces";
    $username = str_replace(' ', '_', $_POST['username']);

}


if (!empty($_POST['password']) && isset($_POST['password'])) {
    $password = $_POST['password'];
}
if (!empty($_POST['user_role']) && isset($_POST['user_role']) && mysqli_real_escape_string($conn, $_POST['user_role'])) {
    $user_role = $_POST['user_role'];
}
if (!empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}

//checking number of username exist already in data base or not?

function no_of_username_already_in_db()
{
    global $conn, $username;
    $sql_username_check = "SELECT * FROM admin_details WHERE username='$username'";
    $result_user = mysqli_query($conn, $sql_username_check);
    $num_users = mysqli_num_rows($result_user);
    return $num_users;
}






//checking number of  email exist already in data base or not?

function no_of_email_already_in_db()
{
    global $conn, $email;
    $sql_email_check = "SELECT * FROM admin_details WHERE email='$email'";
    $result_email = mysqli_query($conn, $sql_email_check);
    $num_emails = mysqli_num_rows($result_email);
    return $num_emails;
}


//sending back to ajax





if (isset($submit)) {
    if ($submit == "Update Admin") {
        $id = $_POST['uid'];
        update_admin($id);
    }
    if ((no_of_username_already_in_db() == 0) && $submit == "Save Admin") {
        if (no_of_email_already_in_db() == 0) {
            insert_admin();
        } else {

            echo "$msg";

        }

    } else if ((no_of_username_already_in_db() > 0) && $submit == "Save Admin") {


        echo "$msg1";

    }

}




/*
 *Function - insert_admin(): It insert the admin_name, email, password, user_role  fields  values into admin_details tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */

function insert_admin()
{
    global $name, $email, $password, $user_role, $username, $conn;
    $sql = "INSERT INTO `admin_details`( `admin_name`, `email`,`username`, `password`,`user_role`) VALUES ('$name','$email','$username','$password', '$user_role')";
    if (mysqli_query($conn, $sql)) {
        $x = "inserted";

        // echo "New record created successfully";
    }
    echo $x;
}


/*
 *Function - update_admin(): It update  the admin_name, email, password, user_role fields values  into admin_details tables  data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- void , return value - does not return any value.
 */


function update_admin($id)
{
    global $conn, $name, $email, $password, $username, $user_role;



    $sql = "UPDATE `admin_details` SET`admin_name`='$name',`email`='$email',`username`='$username',`password`='$password', `user_role`='$user_role' WHERE `admin_id`='$id'";
    // print_r($sql);
    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        $x = "updated";

        // header("Location: http://practice.indianexpress.com/project1/admin/admin_list.php");

    }
    echo $x;

}





// $id = $_GET['id'];
// $status = $_GET['status'];






/*
 *Function - delete_admin(): It delete  all the details/field values in admin details table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- void , return value - does not return any value.
 */
function delete_admin($id)
{
    global $conn;
    $sql = "DELETE FROM `admin_details` WHERE `admin_id`=$id";
    // console.log(response);
    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/admin_list.php");

}

function update_status($id)
{
    global $conn, $status;
    $status = $_GET['status'];
    if ($status == 1) {
        $status = 0;
    } else if ($status == 0) {
        $status = 1;
    }
    $sql = "UPDATE `admin_details` SET status='$status' WHERE `admin_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
        die();

    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/admin_list.php");

}



// $sql_username_check = "SELECT * FROM admin_details WHERE username='$username'";
// $result_user = mysqli_query($conn, $sql_username_check);
// $num_users = mysqli_num_rows($result_user);

// $sql_email_check = "SELECT * FROM admin_details WHERE email='$email'";
// $result_email = mysqli_query($conn, $sql_email_check);
// $num_emails = mysqli_num_rows($result_email);

?>