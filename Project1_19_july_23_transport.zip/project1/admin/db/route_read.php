<?php
include_once("db.php");

if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
  include_once('../templates/common.php');
  $page = 1;
  if (isset($_POST['page'])) {
    $page = $_POST['page'];
  }

  display_route_table($page);
} else {
  include_once('templates/common.php');
}



/*
 * Function -get_all_route_data() : It fetch data from table routes and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- object , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */



/*
 *Function - get_all_route_data_by_id(): It fetch a single row  from table  routes  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-routes.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */

function get_route_data_by_id($id)
{
  global $conn;
  $query = "SELECT  `timeperiod`,`time_id`,`location_id`, `vehicle_id`,status FROM `routes` WHERE `route_id`='$id'";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
    $arr['timeperiod'] = $row['timeperiod'];

    $arr['time_id'] = $row['time_id'];
    $arr['location_id'] = $row['location_id'];
    $arr['vehicle_id'] = $row['vehicle_id'];
    $arr['status'] = $row['status'];
    return $arr;

  }



}

function get_timing_data_by_id($id)
{
  global $conn;
  $query = "SELECT `time_slot`,`timeperiod` FROM `timing` WHERE `time_id`='$id'";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['time_slot'] = $row['time_slot'];
    $arr['timeperiod'] = $row['timeperiod'];


    return $arr;

  }



}


function get_location_data_by_id($id)
{
  global $conn;
  $query = "SELECT * FROM locations WHERE location_id= $id";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
    $arr['location_name'] = $row['location_name'];
    $arr['location_distance'] = $row['location_distance'];
    $arr['location_parent_id'] = $row['location_parent_id'];
    $arr['location_id'] = $row['location_id'];
    $arr['status'] = $row['status'];
    return $arr;

  }



}

function get_vehicle_info($id)
{
  global $conn;
  $query = "SELECT  `vehicle_no`, `model`, `capacity`, status  FROM `vehicle` WHERE `vehicle_id`='$id'";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['vehicle_no'] = $row['vehicle_no'];
    $arr['model'] = $row['model'];
    $arr['capacity'] = $row['capacity'];
    $arr['status'] = $row['status'];
    return $arr;

  }

}


function display_route_table($cur_page)
{
  global $conn, $table_data;
  $offset = ($cur_page - 1) * LIMIT;
  $start_from = get_start_from_value_route($cur_page);
  $sql = "SELECT * FROM routes ORDER BY route_id DESC LIMIT " . LIMIT . " OFFSET $offset";
  $result = mysqli_query($conn, $sql);



  $n = $start_from;
  $start = 0;
  while ($row1 = mysqli_fetch_assoc($result)) { ?>
    <?php $table_data ?>
    <tr>
      <?php if ($row1['status'] == 0) { ?>
        <td class="disable bold" scope="row">
          <?php echo $n + $start; ?>
        </td>

        <td class="disable">
          <?php
          if ($row1['timeperiod'] == 'M') {
            echo "Morning";
          } else {

            echo "Evening";
          } ?>
        </td>
        <?php
        if ($row1['timeperiod'] == 'E') {

          $start_point = "Office";

          // print_r($time_ids_checked_array);
          $row2 = get_location_data_by_id($row1['location_id']);

          if ($row2) {

            $end_point = $row2['location_name'];
          } else {
            $end_point = "Location id  not found";
          }



        } else if ($row1['timeperiod'] == 'M') {
          $end_point = "Office";


          $row2 = get_location_data_by_id($row1['location_id']);

          if ($row2) {

            $start_point = $row2['location_name'];
          } else {
            $start_point = "Location id  not found";
          }



        }




        ?>

        <td class="disable">
          <?php
          echo ucwords(strtolower($start_point));
          ?>
        </td>
        <td class="disable">
          <?php
          echo ucwords(strtolower($end_point));
          ?>
        </td>
        <td class="disable">
          <?php


          $row2 = get_vehicle_info($row1['vehicle_id']);

          if ($row2) {


            $model = ucwords(strtolower($row2['model']));
            echo " $model ($row2[vehicle_no])";
          } else {
            echo "Vehicle id  not found";
          } ?>
        </td>
        <td class="disable">
          <?php


          $row2 = get_timing_data_by_id($row1['time_id']);

          if ($row2) {
            echo "$row2[time_slot]";
          } else {
            echo "Time id  not found";
          } ?>
        </td>
        <td class="disable">

          <!-- Delete Button -->
          <button type="button" class="btn btn-danger" button style="margin-right:10px" name="route"
            id="<?php echo $row1['route_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
            Delete
          </button>
          <!-- Status  Button -->
          <?php


          if ($row1['status'] == 1) { ?>
            <input type="hidden" class="form-control" name="status" id="status_data" value="status">
            <button type="button" class="btn btn-success" id="<?php echo $row1['route_id'] ?>" name="route"
              value="<?php echo $row1['status'] ?>" onclick='return updatestatus_route(this.id, this.name, this.value)'
              data-title="Click to Disable">
              Status
            </button>
          <?php } else if ($row1['status'] == 0) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-warning" id="<?php echo $row1['route_id'] ?>" name="route"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_route(this.id, this.name, this.value)'
                data-title="Click to Enable">
                Status
              </button>
            <?php }
          ?>

        </td>
      <?php } else if ($row1['status'] == 1) { ?>
          <td class="bold" scope="row">
          <?php echo $n + $start; ?>
          </td>

          <td>
            <?php
            if ($row1['timeperiod'] == 'M') {
              echo "Morning";
            } else {

              echo "Evening";
            }
            ?>
          </td>

          <?php
          if ($row1['timeperiod'] == 'E') {

            $start_point = "Office";

            $row2 = get_location_data_by_id($row1['location_id']);

            if ($row2) {

              $end_point = $row2['location_name'];
            } else {
              $end_point = "Location id  not found";
            }



          } else if ($row1['timeperiod'] == 'M') {
            $end_point = "Office";


            $row2 = get_location_data_by_id($row1['location_id']);

            if ($row2) {

              $start_point = $row2['location_name'];
            } else {
              $start_point = "Location id  not found";
            }



          }




          ?>

          <td>
            <?php
            echo ucwords(strtolower($start_point));
            ?>
          </td>
          <td>
            <?php
            echo ucwords(strtolower($end_point));
            ?>
          </td>
          <td>
            <?php


            $row2 = get_vehicle_info($row1['vehicle_id']);

            if ($row2) {

              $model = ucwords(strtolower($row2['model']));
              echo " $model ($row2[vehicle_no])";
            } else {
              echo "Vehicle id  not found";
            } ?>
          </td>
          <td>
            <?php


            $row2 = get_timing_data_by_id($row1['time_id']);

            if ($row2) {
              echo "$row2[time_slot]";
            } else {
              echo "Time id  not found";
            } ?>
          </td>
          <td>
            <!-- Edit Button -->
            <a href="route_form.php?action=edit&id=<?php echo "$row1[route_id]" ?>">
              <button type="button" class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
                Edit
              </button></a>

            <!-- Delete Button -->
            <button type="button" class="btn btn-danger" button style="margin-right:10px" name="route"
              id="<?php echo $row1['route_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
              Delete
            </button>
            <!-- Status  Button -->
            <?php


            if ($row1['status'] == 1) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-success" id="<?php echo $row1['route_id'] ?>" name="route"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_route(this.id, this.name, this.value)'
                data-title="Click to Disable">
                Status
              </button>
            <?php } else if ($row1['status'] == 0) { ?>
                <input type="hidden" class="form-control" name="status" id="status_data" value="status">
                <button type="button" class="btn btn-success" id="<?php echo $row1['route_id'] ?>" name="route"
                  value="<?php echo $row1['status'] ?>" onclick='return updatestatus_route(this.id, this.name, this.value)'
                  data-title="Click to Enable">
                  Status
                </button>
              <?php }
            ?>
          <?php } ?>

      </td>
    </tr>

    <?php $n++;
  } ?>

<?php return $table_data;

} ?>

<?php
function get_start_from_value_route($cur_page)
{
  $start_from = (LIMIT * ($cur_page - 1)) + 1;
  return $start_from;
}

function get_total_pages_route()
{
  $total_rows = get_total_num_of_table_row('routes');
  $total_number_of_pages = ceil($total_rows / LIMIT);
  return $total_number_of_pages;
}



function get_all_timing_data()
{
  global $conn;
  $query = "SELECT * FROM `timing` ";
  // FETCHING DATA FROM DATABASE
  $result = mysqli_query($conn, $query);

  return $result;
}

function get_all_vehicle_data()
{
  global $conn;
  $query = "SELECT * FROM `vehicle` ";
  $result = mysqli_query($conn, $query);

  return $result;
}

function categoryTree_Route($location_parent_id = 0, $sub_mark = '')
{

  global $conn, $selected, $route_location_id;
  $id = $_GET['id'];
  $route_data = get_route_data_by_id($id);
  $route_location_id = $route_data['location_id'];

  echo "$route_location_id";


  $query = "SELECT * FROM `locations` WHERE `location_parent_id`='$location_parent_id'";
  $result = mysqli_query($conn, $query);


  if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
      $selected = '';
      if ($_GET['action'] == "edit" && $route_location_id == $row['location_id']) {
        $selected = 'selected';
      }
      ?>
      <option value="<?php echo $row['location_id']; ?>" <?php echo $selected ?>> <?php echo "$sub_mark " ?>
        <?php echo $row['location_name'] ?>
      </option>;
      <?php categoryTree_Route($row['location_id'], $sub_mark . '---');
    }
  }


}




?>