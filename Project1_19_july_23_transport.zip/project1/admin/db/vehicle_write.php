<?php
include_once("db.php");


$file = $_POST['file'];

echo $file;


if (isset($_POST['vehicle_no']) && !empty($_POST['vehicle_no']) && filter_var($_POST['vehicle_no'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['vehicle_no'])) {
    $vehicle_no = $_POST['vehicle_no'];
}
if (isset($_POST['model']) && !empty($_POST['model']) && filter_var($_POST['model'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['model'])) {
    $model = $_POST['model'];
}
if (isset($_POST['capacity']) && !empty($_POST['capacity']) && filter_var($_POST['capacity'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['capacity'])) {
    $capacity = $_POST['capacity'];
}

if (isset($_POST['submit']) && !empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}

if (isset($submit)) {
    if ($submit == "Update Vehicle") {
        $id = $_POST['uid'];
        update_vehicle($id);
    }
    if ($submit == "Save Vehicle") {
        insert_vehicle();
    }

}


/*
 *Function - insert_vehicle(): It insert the 'vehicle_no`, `model`, `capacity`, `driver_name`, `driver_licence_no` field  values into vehicle  tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */


function insert_vehicle()
{
    global $vehicle_no, $model, $capacity, $conn;
    $sql = "INSERT INTO `vehicle`( `vehicle_no`, `model`, `capacity`) VALUES ('$vehicle_no','$model','$capacity')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    // header("Location: http://practice.indianexpress.com/project1/admin/vehicle_list.php");
}



/*
 * Function - update_vehicle(): It update  'vehicle_no`, `model`, `capacity`, `driver_name`, `driver_licence_no` field  values into vehicle table data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table- vehicle  .
 * Return  value: data type- void , return value - does not return any value.
 */
function update_vehicle($id)
{
    global $vehicle_no, $model, $capacity, $driver_name, $driver_licence_no, $conn;



    $sql = "UPDATE `vehicle` SET `vehicle_no`='$vehicle_no',`model`='$model',`capacity`='$capacity' WHERE `vehicle_id`='$id'";
    print_r($sql);
    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        echo "success";
        header("Location: http://practice.indianexpress.com/project1/admin/vehicle_list.php");

    }

}
$id = $_GET['id'];
$status = $_GET['status'];


if ($status == 1) {
    $status = 0;
} else if ($status == 0) {
    $status = 1;
}

if (isset($id)) {
    if ($_GET['action'] == "delete") {
        delete_vehicle($id);
    } else if ($_GET['action'] == "status") {
        update_status($id);


    }
}

/*
 *Function - delete_employee(): It delete  all the details/fields values in vehicle  table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-vehicle.
 * Return  value: data type- void , return value - does not return any value.
 */
function delete_vehicle($id)
{
    global $conn;
    $sql = "DELETE FROM `vehicle` WHERE `vehicle_id`='$id' ";

    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/vehicle_list.php");

}

function update_status($id)
{
    global $conn, $status;
    $sql = "UPDATE `vehicle` SET status='$status' WHERE `vehicle_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/vehicle_list.php");

}

?>