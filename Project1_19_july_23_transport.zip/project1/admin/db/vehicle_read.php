<?php
include_once("db.php");
if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
  include_once('../templates/common.php');
  $page = 1;
  if (isset($_POST['page'])) {
    $page = $_POST['page'];
  }

  display_vehicle_table($page);
} else {
  include_once('templates/common.php');
}


/*
 * Function -get_all_vehicle_data() : It fetch data from table vehicle and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- object , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */

function get_all_vehicle_data()
{
  global $conn;
  $query = "SELECT * FROM `vehicle` ";
  $result = mysqli_query($conn, $query);

  return $result;
}

/*
 *Function - get_all_vehicle_data_by_id(): It fetch a single row  from table  vehicle  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-vehicle.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */

function get_vehicle_data_by_id($id)
{
  global $conn;
  $query = "SELECT * FROM `vehicle`  WHERE `vehicle_id`= $id";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['vehicle_no'] = $row['vehicle_no'];
    $arr['model'] = $row['model'];
    $arr['capacity'] = $row['capacity'];
    $arr['status'] = $row['status'];

    return $arr;

  }
}
/*
 *Function - get_vehicle_info(): It fetch a single row with specefic field values of fields - 'vehicle_no`, `model`, `capacity` from table vehicle  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-vehicle.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */
function get_vehicle_info($id)
{
  global $conn;
  $query = "SELECT  `vehicle_no`, `model`, `capacity`, status  FROM `vehicle` WHERE `vehicle_id`='$id'";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) == 1) {
    // output data of each row} 
    $row = mysqli_fetch_array($result);
    $arr['vehicle_no'] = $row['vehicle_no'];
    $arr['model'] = $row['model'];
    $arr['capacity'] = $row['capacity'];
    $arr['status'] = $row['status'];
    return $arr;

  }

}

function display_vehicle_table($cur_page)
{
  global $conn, $table_data;
  $offset = ($cur_page - 1) * LIMIT;
  $start_from = get_start_from_value_vehicle($cur_page);
  $sql = "SELECT * FROM vehicle ORDER BY vehicle_id DESC LIMIT " . LIMIT . " OFFSET $offset";
  $result = mysqli_query($conn, $sql);

  $n = $start_from;
  $start = 0;
  while ($row1 = mysqli_fetch_assoc($result)) { ?>
    <?php $table_data ?>
    <tr>
      <?php if ($row1['status'] == 0) { ?>
        <td class="disable bold" scope="row">
          <?php echo $n + $start; ?>
        </td>
        <td class="disable">
          <?php echo $row1['vehicle_no'] ?>
        </td>
        <td class="disable">
          <?php
          echo ucwords(strtolower($row1['model'])) ?>
        </td>
        <td class="disable">
          <?php echo $row1['capacity'] ?>
        </td>


        <td class="disable">


          <!-- Delete Button -->
          <button type="button" class="btn btn-danger" button style="margin-right:10px" name="vehicle"
            id="<?php echo $row1['vehicle_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
            Delete
          </button>
          <!-- Status  Button -->
          <?php


          if ($row1['status'] == 1) { ?>
            <input type="hidden" class="form-control" name="status" id="status_data" value="status">
            <button type="button" class="btn btn-success" id="<?php echo $row1['vehicle_id'] ?>" name="vehicle"
              value="<?php echo $row1['status'] ?>" onclick='return updatestatus_vehicle(this.id, this.name, this.value)'
              data-title="Click to Disable">
              Status
            </button>
          <?php } else if ($row1['status'] == 0) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-warning" id="<?php echo $row1['vehicle_id'] ?>" name="vehicle"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_vehicle(this.id, this.name, this.value)'
                data-title="Click to Enable">
                Status
              </button>
            <?php }
          ?>
        </td>

      <?php } else if ($row1['status'] == 1) { ?>
          <td class="bold" scope="row">
          <?php echo $n + $start; ?>
          </td>
          <td>
          <?php echo $row1['vehicle_no'] ?>
          </td>
          <td>
          <?php echo ucwords(strtolower($row1['model'])) ?>
          </td>
          <td>
          <?php echo $row1['capacity'] ?>
          </td>


          <td>
            <!-- Edit Button -->
            <a href="vehicle_form.php?action=edit&id=<?php echo "$row1[vehicle_id]" ?>">
              <button type="button" class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
                Edit
              </button></a>

            <!-- Delete Button -->
            <button type="button" class="btn btn-danger" button style="margin-right:10px" name="vehicle"
              id="<?php echo $row1['vehicle_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
              Delete
            </button>

            <!-- Status  Button -->
            <?php


            if ($row1['status'] == 1) { ?>
              <input type="hidden" class="form-control" name="status" id="status_data" value="status">
              <button type="button" class="btn btn-success" id="<?php echo $row1['vehicle_id'] ?>" name="vehicle"
                value="<?php echo $row1['status'] ?>" onclick='return updatestatus_vehicle(this.id, this.name, this.value)'
                data-title="Click to Disable">
                Status
              </button>
            <?php } else if ($row1['status'] == 0) { ?>
                <input type="hidden" class="form-control" name="status" id="status_data" value="status">
                <button type="button" class="btn btn-success" id="<?php echo $row1['vehicle_id'] ?>" name="vehicle"
                  value="<?php echo $row1['status'] ?>" onclick='return updatestatus_vehicle(this.id, this.name, this.value)'
                  data-title="Click to Enable">
                  Status
                </button>
              <?php }
            ?>
          <?php } ?>
      </td>
    </tr>

    <?php $n++;
  } ?>
  <?php return $table_data;

} ?>
<?php
function get_start_from_value_vehicle($cur_page)
{
  $start_from = (LIMIT * ($cur_page - 1)) + 1;
  return $start_from;
}

function get_total_pages_vehicle()
{
  $total_rows = get_total_num_of_table_row('vehicle');
  $total_number_of_pages = ceil($total_rows / LIMIT);
  return $total_number_of_pages;
}
?>