<?php
$page_name = 'Route Form Page';

include_once('templates/header.php');
include_once("db/route_read.php");

$result = get_all_vehicle_data();
if ($result->num_rows > 0) {
    $vehicles = mysqli_fetch_all($result, MYSQLI_ASSOC);

}


$result = get_all_timing_data();
if ($result->num_rows > 0) {
    $timings = mysqli_fetch_all($result, MYSQLI_ASSOC);
}



$action = $_GET['action'];

if (isset($action)) {
    if ($action == "edit") {
        $uid = $_GET['id'];

        $data = get_route_data_by_id($uid);
        // print_r($data);
        $timeperiod = $data['timeperiod'];
        $time_id = $data['time_id'];
        $vehicle_id = $data['vehicle_id'];
        $location_id = $data['location_id'];
        $status = $data['status'];
        $var = "Update Route";


    } elseif ($action == "add") {
        $timeperiod = "";
        $time_id = "";
        $vehicle_id = "";
        $location_id = "";
        $status = '1';

        $var = "Save Route";
    }

}
?>

<body>
    <div class="container mt-3">
        <h2>Enter Routes Details</h2>
        <form id="route_form" , method="POST">
            <div class="mb-3 mt-3">
                <label for="timeperiod">Time Period:</label>
                <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                <input type="radio" name="timeperiod" id="timeperiod" value="M" <?php echo ($timeperiod === 'M') ? "CHECKED" : " " ?> />Morning
                <input type="radio" name="timeperiod" id="timeperiod" value="E" <?php echo ($timeperiod === 'E') ? "CHECKED" : " " ?> />Evening

            </div>

            <div class="mb-3 mt-3">
                <label for="time_id">Choose Time Slot:</label>
                <select name="time_id" class="form-select">
                    <?php
                    foreach ($timings as $timing) {
                        $selected = '';
                        if ($action == 'edit' && $time_id == $timing['time_id']) {
                            $selected = 'selected';
                        }
                        ?>
                        <option period="<?php echo $timing['timeperiod']; ?>" value="<?php echo $timing['time_id']; ?>"
                            <?php echo $selected; ?>>
                            <?php echo "$timing[time_slot]" ?>
                        </option>
                        <?php
                    }
                    ?>
                </select>
            </div>


            <div class="mb-3 mt-3">
                <label for="location_id">Select Location:</label>
                <select name="location_id" class="form-select">
                    <option>
                        <?php echo $location_id ?>
                    </option>
                    <?php categoryTree_Route(); ?>

                </select>
            </div>



            <div class="mb-3 mt-3">
                <label for="time_id">Choose Vehicle:</label>
                <select name="vehicle_id" class="form-select">
                    <option>
                        <?php echo $vehicle_id ?>
                    </option>
                    <?php
                    foreach ($vehicles as $vehicle) {
                        $selected = '';
                        if ($action == 'edit' && $vehicle_id == $vehicle['vehicle_id']) {
                            $selected = 'selected';
                        }
                        ?>
                        <option value="<?php echo $vehicle['vehicle_id']; ?>" <?php echo $selected; ?>>
                            <?php echo "$vehicle[model]($vehicle[vehicle_no])" ?>
                        </option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3 mt-3">
                <label for="status">Route Status:</label>
                <input type="radio" name="status" id="status" value="1" <?php echo ($status == '1') ? "CHECKED" : " " ?> />Enabled

                <input type="radio" name="status" id="status" value="0" <?php echo ($status == '0') ? "CHECKED" : " " ?> />Disabled
            </div>
            <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
            <input type="submit" class="btn btn-primary" name="submit" value="<?php echo $var; ?>" />
        </form>
        <br>
        <a href='http://practice.indianexpress.com/project1/admin/route_list.php'>
            <button class="btn btn-dark">
                Show Route List
            </button>
    </div>

</body>
<?php include("templates/footer.php");





?>






<script>
    // get selected value of radio button by name  to identify which button is selected.

    // Use the querySelectorAll() method to get a collection of the elements with the specific class/element.
    const radioButtons = document.querySelectorAll('input[name="timeperiod"]');

    // get period value of timeslots from select field Morning (period="M") and assign it to morningSlot
    const morningSlot = document.querySelectorAll('[period="M"]');

    // get period value of timeslots from select field Evening (period="E") and assign it to eveningSlot
    const eveningSlot = document.querySelectorAll('[period="E"]');

    function handleRadioClick() {
        // stored the checked value of  timeperiod from user in var timePeriod .Is it  M or E?.
        var timePeriod = document.querySelector('input[name="timeperiod"]:checked').value;
        /*
            Use the querySelectorAll() method to get a collection of the elements with the specific class.
            Use the forEach() method to iterate over the collection.
              On each iteration, use the style object to change the element's styles.
          */
        if (timePeriod == 'M') {
            morningSlot.forEach(slot1 => {
                slot1.style.display = 'inline';
            });
            eveningSlot.forEach(slot2 => {
                slot2.style.display = 'none';
            });
        } else if (timePeriod = 'E') {
            morningSlot.forEach(slot1 => {
                slot1.style.display = 'none';
            });
            eveningSlot.forEach(slot2 => {
                slot2.style.display = 'inline';
            });
        }
    }

    // on clicking radio button it calls the handleRadioClick function
    radioButtons.forEach(radio => {
        radio.addEventListener('click', handleRadioClick);
    });
</script>