<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>
<div class="content">
    <div class="content-left">
        <h1 class="title">Our <span> Services</span></h1>

        <!-- <h2 class="subtitle">Location <span> Routes</span></h2> -->
        <p>
            <?php
            $all_location_ids = get_all_distinct_location_ids();
            $sno = 1;
            foreach ($all_location_ids as $loc_id) { ?>
            <h2>
                <?php $location_name = get_location_name_by_location_id($loc_id);
                $location_name = strtolower($location_name);
                $location_name = ucfirst($location_name);
                echo $sno++; ?>

                <a style="text-decoration: none"
                    href="http://practice.indianexpress.com/project1/location_detail.php?loc_id=<?php echo $loc_id ?>">
                    <?php echo $location_name ?>
                </a>

            </h2>


            <div class="row1">

                <ul class="list1">
                    <li>
                        <?php $area = get_parent_area_by_location_id($loc_id);
                        echo "Area: $area ";
                        ?>
                    </li>
                    <li>
                        <?php $no_of_routes = get_number_of_routes_from_given_location($loc_id);
                        echo "Total Number of routes in Service : $no_of_routes ";
                        ?>
                    </li>
                    `
                </ul>
            </div>
        <?php } ?>





        </p>
        <p>&nbsp;</p>
        <!-- <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p> -->
        <!-- <p><a href="#" class="more">Read More</a></p>


        <div class="row1">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Indian Express Limited is an Indian news media publishing company. It publishes several widely
                    circulated dailies, including The Indian Express and The Financial Express in English, the Loksatta
                    in Marathi and the Jansatta in Hindi. </p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy textof the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
            <p><a href="#" class="more">Read More</a></p>
        </div> -->
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>