<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>

<div class="content">
    <div class="content-left">
        <div class="row1">
            <h1 class="title">Contact & <span>Enquiry Form</span></h1>

            <h2 class="subtitle">Send your<span> queries to us</span></h2>
            <?php
            // if (isset($_GET['msg'])) {
            //     echo "<div class='alert alert-success'>
            //     $_GET[msg]
            //    </div>";
            // } else {
            //     echo '';
            // }
            ?>

            <div class="feedback-form">

                <div>
                    <form id="contact_form" action="admin/db/contact_write.php" method="POST">
                        <input type="text" name="email" id="email" placeholder="Email"></input>
                        <input type="text" name="name" id="name" placeholder="Name"></input>

                        <input type="text" name="mobile" id="mobile" placeholder="Phone number"></input>
                        <textarea name="message" id="message" placeholder="Write something to us"></textarea>


                        <button type="submit" name="submit" value="Send">Submit</button>
                    </form>
                </div>
            </div>


        </div>
        <div class="row2">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Indian Express Limited is an Indian news media publishing company. It publishes several widely
                    circulated dailies, including The Indian Express and The Financial Express in English, the Loksatta
                    in Marathi and the Jansatta in Hindi. <br>
                    It has survived not only five centuries, but also the leap into
                    electronic typesetting.and scrambled it to make a type speascimen book.</p>
            <p>&nbsp;</p>
            <!-- <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.</p>
            <p>&nbsp;</p> -->
            <!-- <p align="right"><a href="#" class="more">Read More</a></p> -->
        </div>
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>


<!-- <html>


<head>
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>

<body>
    <h2>Contact Us</h2>

    <form class="form" action="contactform.php" method="POST">

        <p class="username">
            <input type="text" name="name" id="name" placeholder="Enter your name">
            <label for="name">Name</label>
        </p>

        <p class="useremail">
            <input type="text" name="email" id="email" placeholder="mail@example.com">
            <label for="email">Email</label>
        </p>

        <p class="usercontact">
            <input type="text" name="contact" id="contact" placeholder="contact no.">
            <label for="contact">Phone number</label>
        </p>

        <p class="usertext">
            <textarea name="text" placeholder="Write something to us"></textarea>
            <label for="text">Message</label>
        </p>

        <p class="usersubmit">
            <input type="submit" name="submit" value="Send">
        </p>
    </form>
</body>

</html> -->