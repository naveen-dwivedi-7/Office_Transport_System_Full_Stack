<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>

<?php
if (isset($_GET['loc_id']) && !empty($_GET['loc_id'])) {
    $loc_id = $_GET['loc_id'];
    $clicked_location_id = $loc_id;
}
?>
<?php
$loc_name = get_location_name_by_location_id($clicked_location_id);
$loc_name = strtolower($loc_name);
$loc_name = ucfirst($loc_name);
?>
<div class="content">
    <div class="content-left">

        <h1 class="title">Location Details For<span>
                <?php echo $loc_name ?>
            </span></h1>

        <!-- <h2 class="subtitle">Location <span> Routes</span></h2> -->

        <p> <strong>
                <?php $area = get_parent_area_by_location_id($clicked_location_id);
                echo "Area: $area" ?>
            </strong>
        </p>
        <p><strong>
                <?php $distance = get_location_distance_by_location_id($clicked_location_id);
                echo "Distance: $distance Km" ?>
            </strong>
        </p>
        <br>

        <div class="row1">
            <div id="morning">
                <?php $res = get_all_route_id_time_id_vehicle_id_by_location_id_morning($clicked_location_id); ?>


                <?php if (mysqli_num_rows($res) > 0) { ?>
                    <h2>Routes in Morning </h2>
                    <?php $i = 1 ?>

                    <?php while ($row = mysqli_fetch_assoc($res)) { ?>
                        <h3>
                            <?php echo "Route $i: " ?>
                        </h3>
                        <ul class="list1">


                            <li>

                                <?php echo get_time_slot_by_time_id($row['time_id']); ?>

                            </li>

                            <?php $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']); ?>


                            <li>
                                <?php echo "Vehicle:$data[model]"; ?>
                            </li>
                            <li>
                                <?php echo " Capacity:$data[capacity]"; ?>
                            </li>
                            <?php $route_id = $row['route_id'];

                            ?>

                            <p><a href="book_route.php?r_id=<?php echo $route_id ?>" class="more">Book Route
                                    <?php echo $i ?>
                                </a></p>
                            <?php $i++; ?>

                        </ul>
                    <?php }

                } ?>

            </div>
        </div>

        <div class="row1">
            <div id="evening">
                <?php $res = get_all_route_id_time_id_vehicle_id_by_location_id_evening($clicked_location_id); ?>

                <?php if (mysqli_num_rows($res) > 0) { ?>
                    <br>
                    <h2>Routes in Evening </h2>
                    <?php $i = 1 ?>
                    <?php while ($row = mysqli_fetch_assoc($res)) { ?>
                        <h3>
                            <?php echo "Route $i: " ?>
                        </h3>
                        <ul class="list1">
                            <li>
                                <?php echo get_time_slot_by_time_id($row['time_id']); ?>
                            </li>

                            <?php $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']); ?>


                            <li>
                                <?php echo "Vehicle:$data[model]"; ?>
                            </li>
                            <li>
                                <?php echo " Capacity:$data[capacity]"; ?>
                            </li>
                            <?php $route_id = $row['route_id'];

                            ?>
                            <p><a href="book_route.php?r_id=<?php echo $route_id ?>" class="more">Book Route
                                    <?php echo $i ?>
                                </a></p>
                            <?php $i++; ?>


                        </ul>
                    <?php }

                } ?>
            </div>

        </div>



        </p>
        <p>&nbsp;</p>
        <!-- <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p> -->
        <!-- <p><a href="#" class="more">Read More</a></p>


        <div class="row1">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the indusstandard dummy
                text ever since the 1500s, when an unknown printer took a galley of
                type and scrambleto make a type specimen book.</p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy textof the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
            <p><a href="#" class="more">Read More</a></p>
        </div> -->
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>