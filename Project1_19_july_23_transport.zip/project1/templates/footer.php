<?php ?>

<div class="footer">
    <p>&copy; Copyright 2023. Designed and Developed by <a target="_blank" href="http://www.htmltemplates.net">Naveen
            Dwivedi</a>
    </p>
    <ul>
        <li style="border-left: medium none;"><a href="morning_routes.php"><span>About&nbsp;Us</span></a></li>
        <li><a href="contact_form.php"><span>Contact Us</span></a></li>
        <li style="padding-right: 0px;"><a href="#"><span>Privacy Policy</span></a></li>
    </ul>
</div> <!--end footer -->
</div> <!--end main -->
</div> <!--end page -->
</div> <!--end page-in -->
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js?nhj"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>

<!-- Include here your jquery -->
<script type="application/javascript" src="js/custom-js.js?ver=<?php echo $version ?>"></script>

</html>