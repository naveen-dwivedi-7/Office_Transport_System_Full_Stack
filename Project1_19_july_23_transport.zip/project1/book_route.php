<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>

<div class="content">
    <div class="content-left">
        <h3>
            <?php
            if (isset($_GET['msg'])) {
                echo "<div class='alert alert-success'>
                $_GET[msg]
               </div>";
            } else {
                echo '';
            }
            ?>
            <h3>
                <h1 class="title">Book <i class="fas fa-youtube-square"></i><span> Route</span></h1>

                <!-- <h2 class="subtitle">Location <span> Routes</span></h2> -->

                <?php

                if (isset($_GET['r_id'])) {
                    $r_id = $_GET['r_id'];
                    $route = get_all_route_data_by_route_id($r_id);
                    $rid = $route['route_id'];
                    $tperiod = $route['timeperiod'];
                    $tid = $route['time_id'];
                    $loc_id = $route['location_id'];
                    $veh_id = $route['vehicle_id'];
                    $status = $route['status'];
                    $datetime = $route['datetime'];
                    $timeslot = get_time_slot_by_time_id($tid);
                    $loc_name = get_location_name_by_location_id($loc_id);




                } else {
                    $r_id = "Not Found";
                    $route = "";
                    $rid = "";
                    $tperiod = "";
                    $tid = "";
                    $loc_id = "";
                    $veh_id = "";
                    $status = "";
                    $datetime = "";
                    $timeslot = "";
                    $loc_name = "";
                }
                // if(isset($_GET['r_id'])){
                //     echo $_GET['r_id'];
                // }
                // else{
                //     echo "rid not found";
                // }
                // echo $_GET['r_id'];
                $all_distinct_location_id = get_all_distinct_location_ids();
                if ($tperiod == 'M') {
                    $all_distinct_time_id_mor = get_all_distinct_morning_time_ids();
                }
                if ($tperiod == "E") {
                    $all_distinct_time_id_eve = get_all_distinct_evening_time_ids();
                }
                // $all_distinct_time_ids = get_all_distinct_time_ids();
                // $all_route_ids = get_all_route_ids();
                
                ?>

                <div class="row1">

                    <ul class="list1">
                        <h2>

                            <?php
                            if ($tperiod == "M") {
                                echo "Assumed booking for route id : $rid is already not booked /booked. you want to book route from location $loc_name to office in the morning time slot at time  :$timeslot";
                            }
                            if ($tperiod == "E") {
                                echo "Assumed booking for route id : $rid is already not booked /booked. you want to book route from office to $loc_name  in the evening time slot at time  :$timeslot";
                            }

                            ?>


                            <h2>
                                <div class="feedback-form">

                                    <div>
                                        <form id="book_route_form" action="admin/db/book_route_write.php" method="POST">

                                            <input type="text" name="name" id="name" placeholder="Name"></input>
                                            <?php if (!isset($_GET['r_id'])) { ?>
                                                <label for="location_id">Choose a Location:</label>
                                                <select name="location_id" id="location_id"
                                                    onchange='get_location_select_value()'>
                                                    <option> -- select an option -- </option>
                                                    <?php foreach ($all_distinct_location_id as $loc_id) { ?>
                                                        <?php $loc_name = get_location_name_by_location_id($loc_id) ?>
                                                        <option value="<?php echo $loc_id ?>"><?php echo $loc_name ?></option>
                                                    <?php } ?>
                                                </select>
                                                <?php
                                                $location_selectedValue = $_COOKIE['location_selectedValue'];
                                                // echo $location_selectedValue;
                                                $all_distinct_time_ids = get_time_ids_by_selected_location_id($location_selectedValue);

                                                ?>
                                                <br>
                                                <label for="time_id">Choose a Time:</label>
                                                <select name="time_id" id="time_id" onchange='get_time_select_value()'>
                                                    <option> -- select an option -- </option>
                                                    <?php foreach ($all_distinct_time_ids as $time_id) { ?>
                                                        <?php $timeslot = get_time_slot_by_time_id($time_id) ?>
                                                        <option value="<?php echo $time_id ?>"><?php echo $timeslot ?></option>
                                                    <?php } ?>
                                                </select>
                                                <?php
                                                $time_selectedValue = $_COOKIE['time_selectedValue'];
                                                // echo $time_selectedValue;
                                                $all_distinct_route_ids = get_route_ids_by_selected_time_id($time_selectedValue);

                                                ?>
                                                <br>
                                                <label for="route_id">Choose a Route :</label>
                                                <select name="route_id" id="route_id" onchange='get_route_select_value()'>
                                                    <option> -- select an option -- </option>
                                                    <?php foreach ($all_distinct_route_ids as $route_id) { ?>

                                                        <option value="<?php echo $route_id ?>"><?php
                                                           $route = get_all_route_data_by_route_id($route_id);
                                                           $veh_id = $route['vehicle_id'];
                                                           $data = get_vehicle_data_by_vehicle_id($veh_id);
                                                           echo "$route_id : $data[model] Capacity:$data[capacity]";

                                                           ?></option>
                                                    <?php } ?>
                                                </select>
                                                <br>
                                            <?php }

                                            ?>

                                            <?php if (isset($_GET['r_id'])) { ?>
                                                <label for="location_id">Choose a Location:</label>
                                                <select name="location_id" id="location_id">
                                                    <option value="<?php echo $loc_id ?>"><?php echo $loc_name ?>
                                                    </option>

                                                </select>

                                                <br>


                                                <label for="time_id">Choose a Time:</label>
                                                <select name="time_id" id="time_id">
                                                    <option value="<?php echo $tid ?>"><?php echo $timeslot ?>
                                                    </option>

                                                </select>

                                                <br>


                                                <label for="route_id">Choose a Route :</label>
                                                <select name="route_id" id="route_id">

                                                    <option value="<?php echo $rid ?>"><?php
                                                       $route = get_all_route_data_by_route_id($rid);
                                                       $veh_id = $route['vehicle_id'];
                                                       $data = get_vehicle_data_by_vehicle_id($veh_id);
                                                       echo "$rid : $data[model] Capacity:$data[capacity]"; ?>
                                                    </option>

                                                </select>
                                            <?php } ?>


                                            <input type="text" name="email" id="email"
                                                placeholder="Enter Employee Email"></input>

                                            <button type="submit" name="submit" value="Book Route">Book Route</button>
                                        </form>
                                    </div>
                                </div>

                    </ul>
                </div>






                </p>
                <p>&nbsp;</p>

    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>

<script>

    // function get_location_select_value() {
    //     var location_selectedValue = document.getElementById("location_id").value;
    //     console.log(location_selectedValue);



    // }
    // function get_time_select_value() {

    //     var time_selectedValue = document.getElementById("time_id").value;
    //     console.log(time_selectedValue);


    // }
    // function get_route_select_value() {

    //     var route_selectedValue = document.getElementById("route_id").value;
    //     console.log(route_selectedValue);


    // }

</script>