<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);



$name = $_COOKIE['name'];
echo $name;



?>
<script>
    var user_name = "Rohit";
    document.cookie = "name = " + user_name;
</script>
<?php
// include_once('./admin/db/db.php');


// $morning_time_ids = array();
// $morning_location_ids = array();
// $morning_vehicle_id = array();
// $morning_vehicle_ids = array();

// function get_time_slot_by_time_id($time_id)
// {
//     global $conn;
//     $sql = "SELECT  `time_slot` FROM `timing` WHERE time_id=$time_id";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) == 1) {

//         $row = mysqli_fetch_array($result);
//         $timeSlot = $row['time_slot'];
//         return $timeSlot;
//     }
// }
// function get_location_name_by_location_id($loc_id)
// {
//     global $conn;
//     $sql = "SELECT  `location_name` FROM `locations` WHERE location_id=$loc_id";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) == 1) {

//         $row = mysqli_fetch_array($result);
//         $location_name = $row['location_name'];
//         return $location_name;
//     }
// }
// function get_vehicle_data_by_vehicle_id($veh_id)
// {
//     global $conn;
//     $sql = "SELECT  `model`,`capacity`  FROM `vehicle` WHERE vehicle_id=$veh_id";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) == 1) {
//         $row = mysqli_fetch_array($result);
//         $arr['model'] = $row['model'];
//         $arr['capacity'] = $row['capacity'];

//         return $arr;

//     }
// }
// function get_all_time_id_by_location_id($id)
// {
//     global $conn;
//     $sql = "SELECT `time_id` FROM `routes` WHERE location_id=$id";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_array($result)) {
//             $morning_time_ids[] = $row['time_id'];
//         }
//     }
//     return $morning_time_ids;
// }
// function get_all_vehicle_id_by_location_id($id)
// {
//     global $conn;
//     $sql = "SELECT `vehicle_id` FROM `routes` WHERE location_id=$id";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_array($result)) {
//             $morning_vehicle_ids[] = $row['vehicle_id'];
//         }
//     }
//     return $morning_vehicle_ids;
// }
// function get_morning_time_id_vehicle_id_by_location_id($id)
// {
//     global $conn;
//     $sql = "SELECT  `time_id`, `vehicle_id` FROM `routes` WHERE location_id=$id AND timeperiod='M'";
//     $result = mysqli_query($conn, $sql);

//     return $result;
// }
// function get_morning_time_vehicle_location_ids()
// {
//     global $conn;
//     $sql = "SELECT  `time_id`, `vehicle_id`, `location_id` FROM `routes` WHERE timeperiod='M'";
//     $result = mysqli_query($conn, $sql);

//     return $result;
// }
// function get_distinct_morning_location_ids()
// {
//     global $conn;
//     $sql = "SELECT  DISTINCT `location_id` FROM `routes` WHERE timeperiod='M'";
//     $result = mysqli_query($conn, $sql);
//     if (mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_array($result)) {
//             $morning_location_ids[] = $row['location_id'];
//         }
//     }
//     return $morning_location_ids;

// }
// // $result = get_morning_time_vehicle_location_ids();
// // print_r($result);
// // $i = 0;
// // if (mysqli_num_rows($result) > 0) {
// //     while ($row = mysqli_fetch_array($result)) {
// //         echo "<pre>";


// //         echo get_location_name_by_location_id($row['location_id']);
// //         echo "  ";
// //         echo ++$i;
// //         echo "-->";
// //         echo get_time_slot_by_time_id($row['time_id']);
// //         $res = get_vehicle_data_by_vehicle_id($row['vehicle_id']);
// //         echo "$res[model]($res[capacity])";


// //     }
// // }




// echo "<pre>";
// $morning_location_ids = get_distinct_morning_location_ids();


// $len = count($morning_location_ids);
// echo "<pre>";
// for ($i = 0; $i < $len; $i++) {
//     // echo "$morning_location_ids[$i]";
//     echo get_location_name_by_location_id($morning_location_ids[$i]);
//     echo "-->";
//     $res = get_morning_time_id_vehicle_id_by_location_id($morning_location_ids[$i]);
//     if (mysqli_num_rows($res) > 0) {
//         while ($row = mysqli_fetch_assoc($res)) {
//             echo get_time_slot_by_time_id($row['time_id']);
//             echo "  ";
//             $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']);
//             echo "$data[model]($data[capacity])";
//             echo "  ,";

//         }

//     }
//     echo "<br>";

// }


// $time_ids = get_all_time_id_by_location_id($morning_location_ids[$i]);
// $veh_ids = get_all_vehicle_id_by_location_id($morning_location_ids[$i]);

// // echo (count($veh_ids));
// // echo (count($time_ids));
// echo "<br>";

// foreach ($time_ids as $time_id) {
//     echo "$time_id";
//     // $time_slot = get_time_slot_by_time_id($time_id);
//     // echo "$time_slot";
//     echo ",";

// }
// foreach ($veh_ids as $veh_id) {
//     echo "$veh_id";
//     // $row = get_vehicle_data_by_vehicle_id($veh_id);
//     // echo "$row[model]($row[capacity])";
//     echo ",";

// }
// echo "<br>";









/* 
UPDATE registerlogin
SET person_name = :person_name,
user_name = :user_name,
user_password = :user_password
WHERE user_id = :user_id
AND (SELECT COUNT(*) FROM registerlogin WHERE user_name = :user_name AND user_id <> :user_id )  < 1
*/


?>