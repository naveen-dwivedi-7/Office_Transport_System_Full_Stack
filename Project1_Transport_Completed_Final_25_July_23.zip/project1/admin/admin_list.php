<?php


include_once("db/admin_read.php");
$page_name = 'Admin List Page';
include_once('templates/header.php');



$start_from = get_start_from_value_admin($cur_page);
$total_number_of_pages = get_total_pages_admin();


?>

<body>

    <div class="container-xl">
        <br>
        <a href="/project1/admin/admin_form.php?action=add">
            <button type="button" class="btn btn-primary btn-lg" name="add" value="add">
                Add New Admin
            </button>
        </a>

        <div class="col-md-12">
            <br>

            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Username</th>
                        <th scope="col">User Role</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="admin_read.php">

                    <?php display_admin_table($cur_page); ?>



                </tbody>
            </table>
        </div>

        <?php
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>