<?php
$page_name = 'Time Slot Page';

include_once('templates/header.php');
include_once("db/timing_read.php");
include_once("templates/common.php");


$start_from = get_start_from_value_timing($cur_page);
$total_number_of_pages = get_total_pages_timing();


global $am_pm;
$var = "Save Timing";
if (isset($_GET['action'])) {

    if ($_GET['action'] == "edit") {
        $uid = $_GET['id'];
        $data = get_timing_data_by_id($uid);

        $time_slot = $data['time_slot'];
        $timeperiod = $data['timeperiod'];
        $var = "Update Timing";

    } elseif ($_GET['action'] == "add") {

        $time_slot = "";
        $timeperiod = "";
        $var = "Save Timing";

    }

}

?>



<body>

    <div class="container mt-3">
        <h2>Enter Timing Details</h2>
        <form id="timing_form" , method="POST">

            <div class="mb-3 mt-3">
                <div style="padding :20px; width:30%; background-color: aliceblue; box-shadow: 2px 2px black;">
                    <label for="time">Choose Your Time Slot:</label>
                    <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                    <select name="time_slot" id="time_slot" value="<?php echo $time_slot ?>">
                        <option>
                            <?php
                            if (isset($time_slot)) {
                                echo $time_slot;
                            } else {
                                $time_slot = "";
                                echo $time_slot;

                            } ?>
                        </option>

                        <optgroup label="Morning" id="morning">
                            <?php

                            $start1 = strtotime('06:00');
                            $end1 = strtotime('11:45');
                            $i = $start1;
                            ?>

                            <?php while ($i <= $end1) { ?>
                                <?php
                                $starttime = date('h:i a', $i);
                                $i = $i + 15 * 60;
                                $am_pm = date('a', $i);
                                $endtime = date('h:i a', $i);

                                $time_slot = $starttime . " - " . $endtime;
                                echo " <option value='$starttime - $endtime'>$starttime - $endtime</option>"
                                    ?>
                            <?php }

                            ?>
                        </optgroup>
                        <optgroup label=" Evening" id="evening">
                            <?php $start2 = strtotime('16:00');
                            $end2 = strtotime('22:00');
                            $i = $start2;
                            ?>
                            <?php while ($i <= $end2) { ?>
                                <?php
                                $starttime = date('h:i a', $i);
                                $i = $i + 15 * 60;
                                $am_pm = date('a', $i);
                                $endtime = date('h:i a', $i);
                                $time_slot = $starttime . " - " . $endtime;
                                echo " <option value='$starttime - $endtime'>$starttime - $endtime</option>"
                                    ?>
                            <?php }
                            ?>
                        </optgroup>



                    </select>

                    <br>
                    <br>
                    <input type="hidden" class="form-control" name="submit" id="submit_data" value="<?php echo $var ?>">
                    <input type="submit" class="btn btn-primary" name="submit" value="<?php echo $var; ?>">
                </div>
        </form>
        <br>
        <br>
        <!-- <a href='http://practice.indianexpress.com/project1/admin/timing_list.php'>
            <button class="btn btn-dark">
                Show Timing List
            </button> -->
        <hr>
        <div class="container-xl">
            <br>
            <a href="timing_form_list.php?action=add">
                <button type="button" class="btn btn-primary btn-lg " name="add" value="add">
                    Add New Timing
                </button>
            </a>


            <!-- <?php //print_r($_POST); ?> -->
            <div class="col-md-12">
                <br>

                <table class="table table-bordered border-primary">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Sr.No.</th>
                            <th scope="col">Time_Slot</th>
                            <th scope="col">Time Period</th>
                            <th scope="col">Action</th>

                        </tr>
                    </thead>
                    <tbody id="tbody" data-ajaxurl="timing_read.php">

                        <?php display_timing_table($cur_page); ?>



                    </tbody>
                </table>

            </div>
            <?php
            pagination_links($total_number_of_pages);
            ?>
        </div>

</body>
<?php include("templates/footer.php"); ?>