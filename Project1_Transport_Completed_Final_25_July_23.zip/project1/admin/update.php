<?php
print_r($_POST);
$status = $_GET['status'];
$id = $_GET['id'];
$action = $_GET['action'];
echo $action;
echo $status;
echo $id;

?>