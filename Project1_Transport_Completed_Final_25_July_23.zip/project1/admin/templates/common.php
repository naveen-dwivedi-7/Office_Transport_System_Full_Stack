<?php
define("LIMIT", 5);

if (isset($_GET["page"])) {
    $cur_page = $_GET["page"];
} else {
    $cur_page = 1;
}


function checkspace($str)
{
    $ans = false;
    $temp = ' ';
    $len = strlen($str);
    for ($i = 0; $i < $len; $i++) {
        if (str_contains($str[$i], $temp) == true) {
            $ans = true;
            return $ans;
        }
    }
    return $ans;
}

function ageCalculator($dob)
{
    if (!empty($dob)) {
        $birthdate = new DateTime($dob);
        $today = new DateTime('today');
        $age = $birthdate->diff($today)->y;
        return $age;
    } else {
        return 0;
    }
}


function camelrole($x)
{


    $x = ucwords($x);
    if (strrpos($x, "_")) {
        $pos = strrpos($x, "_");
        $x[$pos + 1] = ucfirst($x[$pos + 1]);
    }
    return $x;
}





function get_total_num_of_table_row($table_name)
{
    global $conn;
    $sql = "SELECT * FROM $table_name";
    $result = mysqli_query($conn, $sql);
    $total_no_of_rows = mysqli_num_rows($result);
    return $total_no_of_rows;



}

function get_total_num_of_table_row_morning($table_name)
{
    global $conn;
    $sql = "SELECT * FROM $table_name WHERE timeperiod='M'";
    $result = mysqli_query($conn, $sql);
    $total_no_of_rows = mysqli_num_rows($result);
    return $total_no_of_rows;



}
function get_total_num_of_table_row_evening($table_name)
{
    global $conn;
    $sql = "SELECT * FROM $table_name WHERE timeperiod='E'";
    $result = mysqli_query($conn, $sql);
    $total_no_of_rows = mysqli_num_rows($result);
    return $total_no_of_rows;



}
function get_total_num_of_table_row_request($table_name)
{
    global $conn;
    $sql = "SELECT * FROM $table_name WHERE status='2'";
    $result = mysqli_query($conn, $sql);
    $total_no_of_rows = mysqli_num_rows($result);
    return $total_no_of_rows;



}



function pagination_links($total_number_of_pages)
{
    global $cur_page;
    ?>
    <div>Page <span id="curr_page">1</span> of
        <span id="last_page">
            <?php echo $total_number_of_pages ?>
        </span>
    </div>
    <br>
    <br>
    <div class="pagination" id="pagination_id">
        <a href='' class="pagination_links" id="prev_link" data-page="prev" style="display:none;"> Prev </a>
        <?php
        for ($i = 1; $i <= $total_number_of_pages; $i++) {
            $active = '';
            if ($i === 1) {
                $active = 'active';
            }
            ?>
            <a href='' class='pagination_links <?php echo $active ?>' id="page_link_<?php echo $i ?>"
                data-page="<?php echo $i ?>"> <?php echo $i ?>
            </a>
        <?php } ?>
        <a href='' class="pagination_links" id="next_link" data-page="next"> Next </a>
    </div>
    <?php
}




?>