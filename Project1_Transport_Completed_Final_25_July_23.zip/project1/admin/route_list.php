<?php

$page_name = 'Route List Page';
include_once('templates/header.php');
include_once("db/route_read.php");
include_once("templates/common.php");


$start_from = get_start_from_value_route($cur_page);
$total_number_of_pages = get_total_pages_route();


?>

<body>
    <div class="container-xl">
        <br>
        <a href="/project1/admin/route_form.php?action=add">
            <button type="button" class="btn btn-primary btn-lg" name="add" value="add">
                Add New Route
            </button>
        </a>
        <div class="col-md-12">
            <br>

            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Time period</th>
                        <th scope="col">Start Point</th>
                        <th scope="col">End Point </th>

                        <th scope="col">Vehicle</th>
                        <th scope="col">Time Slot</th>
                        <th scope="col">Filled capacity</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="route_read.php">

                    <?php display_route_table($cur_page); ?>



                </tbody>
            </table>

        </div>
        <?php
        pagination_links($total_number_of_pages);
        ?>
    </div>
</body>


<div id="myModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
        <a href="" id="close_modal">&times;</a>
        <p id="modal_body"></p>
    </div>
</div>
<?php
include('templates/footer.php');
?>