<?php

$page_name = 'Profile Page';
include_once('templates/header.php');
include_once('db/admin_read.php');


$uid = $_SESSION['admin_id'];

$data = get_admin_data_by_id($uid);


$email = $data['email'];
$name = $data['name'];
$password = $data['password'];
$oldpass = $password;
$newpass = "";
$confirmpass = "";




?>

<body>

    <div class="container mt-3">



        <div class="form-group">

            <h2>Edit Profile </h2>
            <form id="update_profile" action="db/profile_write.php" , method="post">

                <div class="mb-3 mt-3">
                    <label for="name">Your Name</label>
                    <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                    <input type="text" class="form-control" id="name" placeholder="Enter Your Name" name="name"
                        value="<?php echo $name ?>">
                </div>
                <div class="mb-3 mt-3">
                    <label for="">Your Email</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email"
                        value="<?php echo $email ?>">
                </div>


                <input type="submit" class="btn btn-primary" name="submit" value="Update Profile">
            </form>
            <br>
            <?php
            if (isset($_GET['msg'])) {
                echo "<div class='alert alert-success'>
                $_GET[msg]
               </div>";
            } else {
                echo " ";
            }
            ?>


        </div>
    </div>


    <hr>

    <div class="container mt-3">



        <h2>Change Password</h2>
        <form id="update_password" action="db/profile_write.php" , method="POST">

            <div class="mb-3 mt-3">
                <label for="oldpass">Old Password</label>
                <input type="hidden" class="form-control" name="uid" value="<?php echo $uid ?>">
                <input type="password" class="form-control" id="oldpass" placeholder="Enter Old Password" name="oldpass"
                    value="<?php //echo $oldpass ?>">
            </div>
            <div class="mb-3 mt-3">
                <label for="newpass">New Password</label>
                <input type="password" class="form-control" id="newpass" placeholder="Enter New Password" name="newpass"
                    value="<?php echo $newpass ?>">
            </div>
            <div class="mb-3 mt-3">
                <label for="confirmpass">Retype New Password</label>
                <input type="password" class="form-control" id="confirmpass" placeholder="Retype New Password"
                    name="confirmpass" value="<?php echo $confirmpass ?>">
            </div>

            <input type="submit" class="btn btn-primary" name="submit" value="Update Password">
        </form>

        <br>

        <?php
        if (isset($_GET['msg1'])) {
            echo "<div class='alert alert-danger'>
                $_GET[msg1]
               </div>";
        } else {
            echo '';
        }
        if (isset($_GET['msg2'])) {
            echo "<div class='alert alert-success'>
                $_GET[msg2]
               </div>";
        } else {
            echo '';
        }
        ?>
</body>
</div>
<?php include("templates/footer.php"); ?>