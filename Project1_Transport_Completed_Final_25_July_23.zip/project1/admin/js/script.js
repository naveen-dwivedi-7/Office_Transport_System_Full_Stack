
// Delete Using ajax and php

function checkdelete1(id, name) {

    if (confirm("Are you sure you want to delete this record")) {
        if (id && name) {
            var file = name;
            $.ajax({
                url: "db/" + file + "_write.php?action=delete&id=" + id,
                type: 'POST',
                data: { id: id },
                success: function (response) {
                    //   alert("data deleted successfully");

                }
            });
        }

        window.location.href =
            "http://practice.indianexpress.com/project1/admin/db/" + file + "_write.php?action=delete&id=" + id;

    }
}



//modal class using ajax

$(".modal_links").on("click", function (e) {
    e.preventDefault();
    var butn = document.activeElement;
    var id = butn.getAttribute("data-id");
    //alert(id);
    $.ajax
        ({
            type: "post",
            url: "http://practice.indianexpress.com/project1/admin/db/route_read.php",
            data: {
                id: id,
                action: 'modal',
            },
            success: function (data) {
                //alert(data);
                console.log(data);
                $('#modal_body').html('');
                $('#modal_body').html(data);
            }
        });

    //get the modal
    var modal = document.getElementById("myModal");
    // When the user clicks the button, open the modal
    modal.style.display = "block";


    var span = document.getElementById("close_modal");
    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

});


//pagination using ajax and jquery, php



$(document).on("click", ".pagination_links", function (e) {
    e.preventDefault();
    var curr_page = $('#curr_page').html();
    var last_page = $('#last_page').html();

    curr_page = parseInt(curr_page, 10);
    last_page = parseInt(last_page, 10);

    var page = $(this).data('page');

    if (!$.isNumeric(page) && $.isNumeric(curr_page)) {
        if (page === 'prev') {
            page = curr_page - 1;
        } else if (page === 'next') {
            page = curr_page + 1;
        }
    }

    page = parseInt(page, 10);

    // alert( "span page--" + curr_page + "-- page-- " + page);
    var ajaxurl = $('#tbody').data('ajaxurl');

    $.ajax
        ({
            type: "post",
            url: "db/" + ajaxurl,
            data: {
                page: page,
                action: 'pagination',
            },
            success: function (data) {
                $('#tbody').html('');
                $('#tbody').html(data);
                // alert(data);
                $('#curr_page').html(page);
                $('.pagination_links').removeClass('active');
                $('#page_link_' + page).addClass('active');
                if (page === 1) {
                    $('#prev_link').hide();
                    $('#next_link').show();
                } else if (page === last_page) {
                    $('#next_link').hide();
                    $('#prev_link').show()
                } else {
                    $('#prev_link').show();
                    $('#next_link').show();
                }
            }
        });

});







//Update  Status using ajax and php

function updatestatus_admin(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            console.log(file);

            window.location = 'http://practice.indianexpress.com/project1/admin/admin_list.php';


        },
        error: function (e) {
            alert('Error: ' + e);
        }
    });
}

function updatestatus_employee(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            console.log(file);




            window.location = 'http://practice.indianexpress.com/project1/admin/employee_list.php';


        },
        error: function (e) {
            alert('Error: ' + e);
        }
    });
}


function updatestatus_location(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            // console.log(file);




            window.location = 'http://practice.indianexpress.com/project1/admin/location_list.php';



        },

    });
}

function updatestatus_route(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            // console.log(file);




            // window.location = 'http://practice.indianexpress.com/project1/admin/route_list.php';


        },

    });
}

function updatestatus_timing(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            // console.log(file);


            window.location = 'http://practice.indianexpress.com/project1/admin/timing_form_list.php';



        },

    });
}

function updatestatus_vehicle(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            // console.log(file);


            window.location = 'http://practice.indianexpress.com/project1/admin/vehicle_list.php';


        },
        // error: function (e) {
        //     alert('Error: ' + e);
        // }
    });
}



function updatestatus_contact(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (file) {
            var file = file;
            console.log(file);

            window.location = 'http://practice.indianexpress.com/project1/admin/contact_list.php';


        },
        error: function (e) {
            alert('Error: ' + e);
        }
    });
}
function updatestatus_request(id, name, value) {


    var action = $(status_data).val();
    var file = name;
    var status = value;


    console.log('status value=' + status);
    console.log('id value=' + id);
    console.log('file_name=' + file);
    console.log('action=' + action);


    $.ajax({
        url: "db/" + file + "_write.php?status=" + status + " &action=status&id=" + id,
        type: 'POST',
        data: {
            id: id,
            action: action,
            status: status,
            file: file,

        },
        success: function (result) {

            alert(result);
            window.location = 'http://practice.indianexpress.com/project1/admin/request_routes_list.php';


        },
        error: function (e) {
            alert('Error: ' + e);
        }
    });
}




//Validating and Inssert and Update using ajax , php , jquery


$().ready(function () {
    jQuery.validator.addMethod("noSpace", function (value, element) {
        return value == '' || value.trim().length != 0;
    }, "No space please and don't leave it empty");

    // validation route form

    $("#route_form").validate({
        rules: {
            timeperiod: {
                required: true,
            },
            time_id: {
                required: true,
            },
            location_id: {
                required: true,
            },
            vehicle_id: {
                required: true,
            },
        },

        messages: {

            timeperiod: {
                required: "Please select your timeperiod",

            },
            time_id: {
                required: "Please select your time_id",

            },

            location_id: {
                required: " Please select your location",

            },
            vehicle_id: {
                required: " Please select your vehicle",

            }

        },
        submitHandler: function (form) {

            // insert  and update admin using ajax and php 

            $.ajax({
                url: 'db/route_write.php',
                type: 'POST',
                data: $("#route_form").serialize(),

                success: function (result) {
                    var action = $(submit_data).val();


                    if (action == "Save Route") {
                        alert("data inserted successfully ");
                    }
                    if (action == "Update Route") {
                        alert("data updated successfully ");
                    }

                }

            });

        }


    });




    //validation admin form
    $("#admin_form").validate({


        rules: {


            name: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            email: {
                required: true,

            },
            username: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            password: {
                required: true,
                minlength: 6
            },
            user_role: {
                required: true,

            },



        },

        errorPlacement: function (error, element) {
            if (element.is(":radio")) {
                error.insertAfter(element.parent());
            } else {
                // This is the default behavior of the script for all fields
                error.insertAfter(element);
            }
        },




        messages: {// function updatestatusemployee(id, name, value) {


            //      var action = $(status_data).val();
            //      var file = name;
            //      var status = value;


            //         console.log('status value=' + status);
            //         console.log('id value=' + id);
            //         console.log('file_name=' + file);
            //         console.log('action=' + action);


            //         $.ajax({
            //             url: "db/" + file + "_write.php?status=" + status +" &action=status&id=" + id,
            //             type:'POST',
            //       

            name: {
                required: " Please enter a display name",
                minlength: " Your username must consist of at least 3 characters"
            },
            email: {
                required: " Please enter a email",

            },
            username: {
                required: " Please enter a username",
                minlength: " Your username must consist of at least 3 characters"
            },
            password: {
                required: " Please enter a password",
                minlength: " Your password must be consist of at least 6 characters"
            },
            user_role: {
                required: " Please select your user role",

            }


        },

        submitHandler: function (form) {

            // insert  and update employee using ajax and php 

            $.ajax({
                url: 'db/admin_write.php',
                type: 'POST',
                data: $("#admin_form").serialize(),

                success: function (response) {
                    // alert(response);
                    // var action = $("#submit_data").val();
                    // if (action == "Save Admin") {
                    //     $("#err").addClass("error_msg").html(response);
                    //     alert("naveen");
                    $('#disp1').replaceWith($('#disp1').html(response));
                    // }
                    // if (action == "Update Admin") {
                    //     //    alert("Data Updated Successfully");
                    //     alert("naveen");
                    //     // $('#disp1').replaceWith($('#disp1').html(response));
                    // }

                }

            });

        },














    });






    //valdation employee form

    $("#employee_form").validate({



        rules: {


            fname: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            lname: {
                required: true,
                noSpace: true,
                minlength: 3

            },
            dob: {
                required: true,

            },

            gender: {
                required: true,

            },





            location_id: {
                required: true,


            },

            "timing_list[]": {
                required: true,
                minlength: 1
            }


        },

        errorPlacement: function (error, element) {
            if (element.is(":radio")) {
                error.insertAfter(element.parent());
            } else if (element.is(":checkbox")) {
                error.insertAfter(element.parent().parent());
            } else {
                // This is the default behavior of the script for all fields
                error.insertAfter(element);
            }
        },


        messages: {

            fname: {
                required: " Please enter a firstname ",
                minlength: " Your first name must consist of at least 3 characters"
            },
            lname: {
                required: " Please enter a lastname",
                minlength: " Your first name must consist of at least 3 characters"
            },
            dob: {
                required: " Please enter a email",

            },
            gender: {
                required: " Please select your  a gender",

            },

            location_id: {
                required: " Please select your  location",

            },
            location_id: {
                required: " Please select your  location",

            },
            "timing_list[]": {
                required: " Please select at least one time slot field",
            },




        },
        submitHandler: function (form) {

            // insert  and update employee using ajax and php 

            $.ajax({
                url: 'db/employee_write.php',
                type: 'POST',
                data: $("#employee_form").serialize(),

                success: function (result) {
                    // var action = $(submit_data).val();
                    // alert(result);
                    $('#display1').replaceWith($('#display1').html(result));
                    // if (action == "Save Employee") {
                    //     alert("data inserted successfully ");
                    // }
                    // if (action == "Update Employee") {
                    //     alert("data updated successfully ");
                    // }

                }

            });

        }
    });



    // validation update profile form

    $("#update_profile").validate({

        rules: {
            email: {
                required: true,

            },
            name: {
                required: true,
                noSpace: true,
                minlength: 3
            }



        },

        messages: {

            username: {
                required: " Please enter a display name",
                minlength: " Your username must consist of at least 3 characters",
                maxlength: " Your username must consist of maximum 20 characters",
                noSpace: true
            },
            email: {
                required: " Please enter a email",
                noSpace: true

            }
        }
    });



    // validation update password form
    $("#update_password").validate({


        rules: {


            newpass: {
                required: true,
                noSpace: true,
                minlength: 5
            },
            confirmpass: {
                required: true,
                noSpace: true,
                minlength: 5

            }



        },

        messages: {


            newpass: {
                required: " Please enter your new password",
                minlength: " Your password must be consist of at least 5 characters"
            },
            confirmpass: {
                required: " Please confirm your password",
                minlength: " Your password must be consist of at least 5 characters"
            }



        }
    });

    // validation location form
    $("#location_form").validate({


        rules: {

            location_name: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            location_distance: {
                required: true,


            },
            location_parent_id: {
                required: true,

            }






        },

        messages: {

            location_name: {
                required: " Please enter your location name",
                minlength: " Your location name must consist of at least 3 characters"
            },
            location_distance: {
                required: " Please enter your location distance",

            },


            location_parent_id: {
                required: " Please select your parent id",

            }

        },

        submitHandler: function (form) {

            // insert  and update location using ajax and php 

            $.ajax({
                url: 'db/location_write.php',
                type: 'POST',
                data: $("#location_form").serialize(),

                success: function (result) {
                    var action = $(submit_data).val();
                    // alert(result);

                    if (action == "Save Location") {
                        alert("data inserted successfully ");
                    }
                    if (action == "Update Location") {
                        alert("data updated successfully ");
                    }

                }

            });

        }
    });




    //validation timing form
    $("#timing_form").validate({


        rules: {


            time_slot: {
                required: true,

            }


        },

        messages: {

            time_slot: {
                required: " Please select your time slot",

            }


        },
        submitHandler: function (form) {

            // insert  and update timing using ajax and php 


            $.ajax({
                url: 'db/timing_write.php',
                type: 'POST',
                data: $("#timing_form").serialize(),

                success: function (result) {
                    var action = $(submit_data).val();
                    //  alert(result);

                    if (action == "Save Timing") {
                        alert("data inserted successfully ");
                    }
                    if (action == "Update Timing") {
                        alert("data updated successfully ");
                    }

                }

            });

        }
    });




    // validation vehcile form
    $("#vehicle_form").validate({


        rules: {


            vehicle_no: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            model: {
                required: true,
                noSpace: true,
                minlength: 3

            },
            capacity: {
                required: true,

            }





        },

        messages: {

            vehicle_no: {
                required: " Please enter a vehicle no ",
                minlength: " Your vehicle number must consist of at least 3 characters"
            },
            model: {
                required: " Please enter a model",
                minlength: " Your model must consist of at least 3 characters"
            },
            capacity: {
                required: " Please enter a capacity",

            }



        },
        submitHandler: function (form) {

            // insert  and update timing using ajax and php 

            $.ajax({
                url: 'db/vehicle_write.php',
                type: 'POST',
                data: $("#vehicle_form").serialize(),

                success: function (result) {
                    var action = $(submit_data).val();
                    //  alert(result);

                    if (action == "Save Vehicle") {
                        alert("data inserted sucessfully ");
                    }
                    if (action == "Update Vehicle") {
                        alert("data updated sucessfully ");
                    }

                }

            });

        }
    });







});



