<?php

include("db/location_read.php");
$page_name = 'Locations List Page';
include_once('templates/header.php');

$start_from = get_start_from_value_location($cur_page);
$total_number_of_pages = get_total_pages_location();


?>

<body>

    <div class="container-xl">
        <br>
        <a href="/project1/admin/location_form.php?action=add">
            <button type="button" class="btn btn-primary btn-lg" name="add" value="add">
                Add New Location
            </button>
        </a>
        <div class="col-md-12">
            <br>

            <table class="table table-bordered border-primary">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sr.No.</th>
                        <th scope="col">Location </th>
                        <th scope="col">Location Area</th>
                        <th scope="col">Distance From office(in KM)</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody id="tbody" data-ajaxurl="location_read.php">

                    <?php display_location_table($cur_page); ?>



                </tbody>
            </table>
        </div>

        <?php
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>