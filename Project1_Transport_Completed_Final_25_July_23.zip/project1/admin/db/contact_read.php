<?php
include 'db.php';

if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
    include_once('../templates/common.php');
    $page = 1;
    if (isset($_POST['page'])) {
        $page = $_POST['page'];
    }

    display_contact_table($page);
} else {
    include_once('templates/common.php');
}

function get_all__enquiry_data()
{
    global $conn;
    $query = "SELECT * FROM `contact_enquiry`";
    $result = mysqli_query($conn, $query);

    return $result;
}
// $res = get_all_contact_enquiry_data();
// if (mysqli_num_rows($res) > 0) {
//     while ($row = mysqli_fetch_assoc($res)) {
//         echo $row['name'];
//         echo "<br>";
//         echo $row['email'];
//         echo "<br>";
//         echo $row['mobile'];
//         echo "<br>";
//         echo $row['message'];
//         echo "<br>";
//     }
// }

function display_contact_table($cur_page)
{
    global $conn, $table_data;
    $offset = ($cur_page - 1) * LIMIT;
    $start_from = get_start_from_value_contact($cur_page);
    $sql = "SELECT * FROM contact_enquiry ORDER BY enquiry_id DESC LIMIT " . LIMIT . " OFFSET $offset ";
    $result = mysqli_query($conn, $sql);
    //SELECT * FROM `admin_details` ORDER BY admin_id DESC

    $n = $start_from;
    $start = 0;

    while ($row1 = mysqli_fetch_assoc($result)) { ?>


        <?php

        if ($row1['status'] == '1') {
            $class_td = "";
            $data_title = "Click to Disable";
            $btn_color = "btn btn-success";


        } else if ($row1['status'] == '0') {
            $class_td = "disable";
            $data_title = "Click to Enable";
            $btn_color = "btn btn-warning";
        }


        ?>
        <?php $table_data ?>
        <tr>

            <td class="bold <?php echo $class_td ?>" scope="row">
                <?php
                echo $n + $start;

                ?>
            </td>
            <td class='<?php echo $class_td ?>'>
                <?php

                $str_mixed = $row1['name'];

                $str_mixed = strtolower($str_mixed);
                echo ucwords($str_mixed);
                ?>
            </td>
            <td class="<?php echo $class_td ?>">
                <?php echo $row1['email'] ?>
            </td>
            <td class="<?php echo $class_td ?>">
                <?php echo $row1['mobile'] ?>
            </td>
            <td class="<?php echo $class_td ?>">
                <?php echo $row1['message'] ?>
            </td>



            <td class="<?php echo $class_td ?>">


                <?php ?>


                <!-- Delete Button  -->
                <button type="button" class="btn btn-danger" button style="margin-right:10px" name="contact"
                    id="<?php echo $row1['enquiry_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
                    Delete
                </button>


                <!-- Status  Button -->

                <input type="hidden" class="form-control" name="status" id="status_data" value="status">
                <button type="button" class="<?php echo $btn_color ?>" id="<?php echo $row1['enquiry_id'] ?>" name="contact"
                    value="<?php echo $row1['status'] ?>" onclick='return updatestatus_contact(this.id, this.name, this.value)'
                    data-title="<?php echo $data_title ?>">
                    Status
                </button>


            </td>


            </td>


        </tr>



        <?php
        $n++;
    } ?>
    <?php return $table_data;

} ?>

<?php
function get_start_from_value_contact($cur_page)
{
    $start_from = (LIMIT * ($cur_page - 1)) + 1;
    return $start_from;
}

function get_total_pages_contact()
{
    $total_rows = get_total_num_of_table_row('contact_enquiry');
    $total_number_of_pages = ceil($total_rows / LIMIT);
    return $total_number_of_pages;
}





?>