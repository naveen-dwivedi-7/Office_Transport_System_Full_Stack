<?php

// It is a database connection ,error and warning  detecting file.

error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

$servername = "127.0.0.1:3306";
$dbusername = "root";
$password = "root";
$dbname = "transport_system";

$version = date("Y-m-d-h-i-s");

global $conn;
$conn = mysqli_connect($servername, $dbusername, $password, $dbname);


if (!$conn) {
    die("sorry we failed to connect: " . mysqli_connect_error());
}


?>