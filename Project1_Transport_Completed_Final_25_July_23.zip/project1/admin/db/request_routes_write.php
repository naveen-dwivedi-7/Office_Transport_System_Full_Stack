<?php
include 'request_routes_read.php';


print_r($_POST);
// die();
if (isset($_GET['id'])) {
    if ($_GET['action'] == "delete") {
        $id = $_GET['id'];
        delete_request_routes($id);
    } else if ($_GET['action'] == "status") {



        update_status_request($_GET['id']);


    }
}
function update_status_request($id)
{
    global $conn, $status;
    $status = $_GET['status'];
    if ($status == '2') {
        $status = '1';
    } else if ($status == '1') {
        $status = '2';
    }
    echo $sql = "UPDATE `route_employee_relation` SET status='$status' WHERE `route_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
        die();

    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/request_routes_list.php");

}
function update_status_request2($id)
{
    global $conn, $status;
    $status = $_GET['status'];
    if ($status == 0) {
        $status = 1;
    } else if ($status == 1) {
        $status = 0;
    }
    echo $sql = "UPDATE `route_employee_relation` SET status='$status' WHERE `route_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
        die();

    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/request_routes_list.php");

}

function delete_request_routes($id)
{
    global $conn;
    $sql = "DELETE FROM `route_employee_relation` WHERE `route_id`=$id";
    // console.log(response);
    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/request_routes_list.php");

}