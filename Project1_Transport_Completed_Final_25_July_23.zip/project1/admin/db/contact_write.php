<?php
include 'contact_read.php';
// print_r($_POST);

if (isset($_POST['submit'])) {
    if (isset($_POST['name']) && !empty($_POST['name'])) {
        $name = $_POST['name'];
    }
    if (isset($_POST['email']) && !empty($_POST['email'])) {
        $email = $_POST['email'];
    }

    if (isset($_POST['mobile']) && !empty($_POST['mobile'])) {
        $mobile = $_POST['mobile'];
    }

    if (isset($_POST['message']) && !empty($_POST['message'])) {
        $message = $_POST['message'];
    }
    if (isset($_POST['submit']) && !empty($_POST['submit'])) {
        $submit = $_POST['submit'];
    }

}


if ($submit == "Send") {
    insert_contact_enquiries();

}
if (isset($_GET['id'])) {
    if ($_GET['action'] == "delete") {
        $id = $_GET['id'];
        delete_contact($id);
    } else if ($_GET['action'] == "status") {

        echo " update status get called";

        update_status($_GET['id']);


    }
}


function insert_contact_enquiries()
{
    $msg1 = "Your query send sucessfully";
    global $name, $email, $mobile, $message, $conn;
    $sql = "INSERT INTO `contact_enquiry`( `name`, `email`, `mobile`, `message`) VALUES ('$name','$email','$mobile','$message')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    }
    header("Location: http://practice.indianexpress.com/project1/contact_form.php?msg=$msg1");
}

function update_status($id)
{
    global $conn, $status;
    $status = $_GET['status'];
    if ($status == 1) {
        $status = 0;
    } else if ($status == 0) {
        $status = 1;
    }
    $sql = "UPDATE `contact_enquiry` SET status='$status' WHERE `enquiry_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
        die();

    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/contact_list.php");

}

function delete_contact($id)
{
    global $conn;
    $sql = "DELETE FROM `contact_enquiry` WHERE `enquiry_id`=$id";
    // console.log(response);
    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/contact_list.php");

}
?>