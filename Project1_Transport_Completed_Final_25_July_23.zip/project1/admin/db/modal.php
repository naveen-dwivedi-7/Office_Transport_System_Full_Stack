<?php

include_once('modal_read.php');

?>
<h2>Employee Details</h2>

<!-- Trigger/Open The Modal -->
<?php
// print_r($_GET);
// die();
if (isset($_GET['emp_id'])) {
    $id = $_GET['emp_id'];

}

$emp = get_employee_data_by_id($id);
$fname = $emp['fname'];
$lname = $emp['lname'];
$name = $fname . " " . $lname;


?>
<button id="myBtn">
    <?php echo $name ?>
</button>

<!-- The Modal -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
        <span class="close">&times;</span>
        <p>
            <?php

            $emp = get_employee_data_by_id($id);
            $fname = $emp['fname'];
            $lname = $emp['lname'];
            $name = $fname . " " . $lname;
            $email = $emp['email'];
            $gender = $emp['gender'];
            if ($gender = "M") {
                $gender = "Male";
            } else {
                $gender = "Female";
            }
            $dob = $emp['dob'];
            echo "Name: $name<br>";
            echo "Email: $email<br>";
            echo "Gender: $gender<br>";
            echo "DOB: $dob<br>";



            ?>

        </p>
    </div>

</div>



</body>

</html>