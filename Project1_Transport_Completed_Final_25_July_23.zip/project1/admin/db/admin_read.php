<?php
// Database connection file
include("db.php");

if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
  include_once('../templates/common.php');
  $page = 1;
  if (isset($_POST['page'])) {
    $page = $_POST['page'];
  }
  display_admin_table($page);
} else {
  include_once('templates/common.php');
}





/*
 * Function -get_all_admin_data() : It fetch data from table admin_details and return a mysqli_result object.
 * Parameters:  data type - void(), value -it does not take any  parameter.
 * Return value : data type- objectinclude_once('../templates/common.php'); , return value  it will return a mysqli_result object which containt he result set obtained from a query against the database and returns FALSE on failure ;
 */

function get_all_admin_data()
{
  global $conn;
  $query = "SELECT * FROM admin_details ";
  $result = mysqli_query($conn, $query);

  return $result;
}

/*
 *Function - get_all_admin_data_by_id(): It fetch a single row  from table admin_details  with given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin_details.
 * Return  value: data type- an array representing the fetched row, return value- returns a fetched row  , null if there are no more rows in the result set, or false on failure.
 */
function get_admin_data_by_id($id)
{
  global $conn;
  $query = "SELECT * FROM admin_details WHERE admin_id= $id";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
    $arr['name'] = $row['admin_name'];
    $arr['email'] = $row['email'];
    $arr['username'] = $row['username'];
    $arr['password'] = $row['password'];
    $arr['user_role'] = $row['user_role'];
    $arr['status'] = $row['status'];
    return $arr;

  }



}



function display_admin_table($cur_page)
{
  global $conn, $table_data;
  $offset = ($cur_page - 1) * LIMIT;
  $start_from = get_start_from_value_admin($cur_page);
  $sql = "SELECT * FROM admin_details ORDER BY admin_id DESC LIMIT " . LIMIT . " OFFSET $offset ";
  $result = mysqli_query($conn, $sql);
  //SELECT * FROM `admin_details` ORDER BY admin_id DESC

  $n = $start_from;
  $start = 0;

  while ($row1 = mysqli_fetch_assoc($result)) { ?>

    <?php

    if ($row1['status'] == '1') {
      $class_td = "";
      $data_title = "Click to Disable";
      $btn_color = "btn btn-success";
    } else if ($row1['status'] == '0') {
      $class_td = "disable";
      $data_title = "Click to Enable";
      $btn_color = "btn btn-warning";
    }
    ?>
    <?php $table_data ?>
    <tr>

      <td class="bold <?php echo $class_td ?>" scope="row">
        <?php echo $n + $start;
        ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php $str_mixed = $row1['admin_name'];

        $str_mixed = strtolower($str_mixed);
        echo ucwords($str_mixed); ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php echo $row1['email'] ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php echo $row1['username'] ?>
      </td>
      <td class="<?php echo $class_td ?>">
        <?php

        echo camelrole($row1['user_role']) ?>
      </td>



      <td class="<?php echo $class_td ?>">
        <!-- Edit Button -->
        <?php if ($row1['status'] == '1') { ?>
          <a href="admin_form.php?action=edit&id=<?php echo $row1['admin_id'] ?>"><button type="button"
              class="btn btn-primary" button style="margin-right:10px" name="edit" value="edit">
              Edit
            </button></a>
        <?php } ?>


        <?php
        if (isset($_SESSION['admin_name']) && $_SESSION['admin_name'] == $row1['admin_name']) {
          echo "";

        } else { ?>

          <!--  Delete Button  -->
          <button type="button" class="btn btn-danger" button style="margin-right:10px" name="admin"
            id="<?php echo $row1['admin_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
            Delete
          </button>
        <?php } ?>

        <!-- Status Button -->


        <input type="hidden" class="form-control" name="status" id="status_data" value="status">
        <button type="button" class="<?php echo $btn_color ?>" id="<?php echo $row1['admin_id'] ?>" name="admin"
          value="<?php echo $row1['status'] ?>" onclick='return updatestatus_admin(this.id, this.name, this.value)'
          data-title="<?php echo $data_title ?>">
          Status
        </button>




      </td>
    <?php } ?>

  </tr>



<?php
    $n++;

    return $table_data;

} ?>

<?php
function get_start_from_value_admin($cur_page)
{
  $start_from = (LIMIT * ($cur_page - 1)) + 1;
  return $start_from;
}

function get_total_pages_admin()
{
  $total_rows = get_total_num_of_table_row('admin_details');
  $total_number_of_pages = ceil($total_rows / LIMIT);
  return $total_number_of_pages;
}








?>