<?php
include 'db.php';

if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
    include_once('../templates/common.php');
    $page = 1;
    if (isset($_POST['page'])) {
        $page = $_POST['page'];
    }

    display_request_table($page);
} else {
    include_once('templates/common.php');
}

function get_all_request_data()
{
    global $conn;
    $query = "SELECT * FROM `route_employee_relation` WHERE status='2'";
    $result = mysqli_query($conn, $query);

    return $result;
}


function display_request_table($cur_page)
{
    global $conn, $table_data;
    $offset = ($cur_page - 1) * LIMIT;
    $start_from = get_start_from_value_request($cur_page);
    $sql = "SELECT * FROM `route_employee_relation` WHERE status='2' ORDER BY route_id DESC LIMIT " . LIMIT . " OFFSET $offset ";
    $result = mysqli_query($conn, $sql);



    $n = $start_from;
    $start = 0;

    while ($row1 = mysqli_fetch_assoc($result)) { ?>
        <?php $table_data ?>
        <tr>


            <td class="bold" scope="row">
                <?php echo $n + $start;
                ?>
            </td>
            <td>
                <?php

                $route_id = $row1['route_id'];
                $row2 = get_all_route_data_by_route_id($route_id);
                $loc_name = get_location_name_by_location_id($row2['location_id']);
                $veh_id = get_vehicle_id_by_route_id($route_id);
                $veh = get_vehicle_data_by_vehicle_id($veh_id);
                $model = $veh['model'];
                $capacity = $veh['capacity'];
                $tid = $row2['time_id'];
                $timeslot = get_time_slot_by_time_id($tid);
                $booked_routes = get_no_of_booked_route($route_id);
                $emp_name = get_employee_data_by_id($row1['emp_id']);
                $name = $emp_name['fname'];
                echo "$loc_name ,$timeslot ,$model";

                ?>
            </td>
            <td>
                <?php echo $name ?>
            </td>

            <td>
                <?php echo "$booked_routes/$capacity"; ?>
            </td>
            <td>
                <?php echo $row1['request_datetime'] ?>
            </td>





            <td>
                <!--  Delete Button  -->
                <button type="button" class="btn btn-danger" button style="margin-right:10px" name="request_routes"
                    id="<?php echo $row1['route_id'] ?>" value="delete" onclick='return checkdelete1(this.id, this.name)'>
                    Delete
                </button>


                <!-- Status Button -->
                <?php
                if ($row1['status'] == '1') {
                    $data_title = "Click to Disable";
                    $status_button = "status";
                    $status_but_col = 'btn-success';
                } else if ($row1['status'] == '2') {
                    $data_title = "Click to ACCEPT ROUTE REQUEST";
                    $status_button = "ACCEPT";
                    $status_but_col = 'btn-dark';
                } else if ($row1['status'] == '0') {
                    $data_title = "Click to Enable";
                    $status_button = "status";
                    $status_but_col = 'btn-success';
                }
                ?>
                <input type="hidden" class="form-control" name="status" id="status_data" value="status">
                <button type="button" class="btn <?php echo $status_but_col; ?>" id="<?php echo $row1['route_id'] ?>"
                    name="request_routes" value="<?php echo $row1['status'] ?>"
                    onclick='return updatestatus_request(this.id, this.name, this.value)'
                    data-title="<?php echo $data_title; ?>">
                    <?php echo $status_button; ?>
                </button>
            </td>

            <?php

            ?>



        </tr>



        <?php
        $n++;
    } ?>
    <?php return $table_data;

} ?>

<?php
function get_start_from_value_request($cur_page)
{
    $start_from = (LIMIT * ($cur_page - 1)) + 1;
    return $start_from;
}

function get_total_pages_request()
{
    $total_rows = get_total_num_of_table_row_request('route_employee_relation');
    $total_number_of_pages = ceil($total_rows / LIMIT);
    return $total_number_of_pages;
}


function get_time_slot_by_time_id($time_id)
{
    global $conn;
    $sql = "SELECT  `time_slot` FROM `timing` WHERE time_id=$time_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $timeSlot = $row['time_slot'];
        return $timeSlot;
    }
}

function get_location_name_by_location_id($loc_id)
{
    global $conn;
    $sql = "SELECT `location_name` FROM `locations` WHERE location_id=$loc_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_assoc($result);
        $location_name = $row['location_name'];
        return $location_name;
    }
}


function get_vehicle_data_by_vehicle_id($veh_id)
{
    global $conn;
    $sql = "SELECT  `model`,`capacity`  FROM `vehicle` WHERE vehicle_id=$veh_id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);
        $arr['model'] = $row['model'];
        $arr['capacity'] = $row['capacity'];

        return $arr;

    }
}

function get_capacity_by_route_id($id)
{
    global $conn;
    $vehid = get_vehicle_id_by_route_id($id);
    $query = "SELECT `capacity` FROM `vehicle` WHERE vehicle_id='$vehid'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $capacity = $row['capacity'];
        return $capacity;

    }

}
function get_vehicle_id_by_route_id($id)
{
    global $conn;
    $query = "SELECT `vehicle_id` FROM `routes` WHERE route_id='$id'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $veh_id = $row['vehicle_id'];
        return $veh_id;

    }


}

function get_no_of_booked_route($id)
{
    global $conn;
    $query = "SELECT COUNT(`route_id`) AS booked_routes FROM `route_employee_relation` WHERE route_id='$id' AND status='1'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $no_of_booked_route = $row['booked_routes'];
        return $no_of_booked_route;

    }

}
function get_employee_data_by_id($id)
{
    global $conn;
    $query = "SELECT * FROM employee WHERE emp_id= $id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // output data of each row} 
        $row = mysqli_fetch_array($result);
        $arr['fname'] = $row['fname'];
        $arr['lname'] = $row['lname'];
        $arr['email'] = $row['email'];
        $arr['gender'] = $row['gender'];
        $arr['dob'] = $row['dob'];
        $arr['emp_profile'] = $row['emp_profile'];
        $arr['location_id'] = $row['location_id'];
        $arr['status'] = $row['status'];

        return $arr;

    }



}

function get_all_route_data_by_route_id($id)
{

    global $conn;
    $query = "SELECT * FROM `routes` WHERE route_id='$id'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $arr['route_id'] = $row['route_id'];
        $arr['timeperiod'] = $row['timeperiod'];
        $arr['time_id'] = $row['time_id'];
        $arr['location_id'] = $row['location_id'];
        $arr['vehicle_id'] = $row['vehicle_id'];
        $arr['status'] = $row['status'];
        $arr['datetime'] = $row['datetime'];
        return $arr;





    }

}

?>