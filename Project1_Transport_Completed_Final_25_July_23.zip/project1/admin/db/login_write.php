<?php
include("db.php");

if (isset($_POST['login'])) {
    login();
}

function login()
{
    global $conn;


    $msg1 = "Invalid username ";
    $msg = "Incorrect password";

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $sql ="SELECT admin_id, admin_name, username, user_role, password FROM admin_details WHERE username='$username'";

    $result = mysqli_query($conn, $sql) or die("Query failed");

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if ($password === $row['password']) {
            session_start();
            $_SESSION['admin_name'] = $row['admin_name'];
            $_SESSION['admin_id'] = $row['admin_id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['user_role'] = $row['user_role'];
            header("Location: http://practice.indianexpress.com/project1/admin/profile.php");
        } else {
            header("Location: http://practice.indianexpress.com/project1/admin/index.php?msg=$msg");
        }
    } else {
        header("Location: http://practice.indianexpress.com/project1/admin/index.php?msg=$msg1");
    }

    
}
?>