<?php
session_start();
include_once("db.php");
include("../templates/common.php");




if (!empty($_POST['email']) && isset($_POST['email']) && filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) && mysqli_real_escape_string($conn, $_POST['email'])) {
    $email = $_POST['email'];
}

if (!empty($_POST['name']) && isset($_POST['name']) && filter_var($_POST['name'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['name'])) {
    $name = $_POST['name'];
}

if (isset($_POST['oldpass']) && !empty($_POST['oldpass'])) {
    $oldpass = $_POST['oldpass'];
}

if (isset($_POST['newpass']) && !empty($_POST['newpass'])) {
    $newpass = $_POST['newpass'];
}
if (isset($_POST['confirmpass']) && !empty($_POST['confirmpass'])) {
    $confirmpass = $_POST['confirmpass'];
}

if (isset($_POST['submit']) && !empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}


if (isset($submit)) {
    if ($submit == "Update Profile") {
        $id = $_POST['uid'];
        update_user_profile($id);
    }


}

/*
 * Function - update_user_profile(): It update  the  user profile with email, and username into admin details data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-admin details .
 * Return  value: data type- void , return value - does not return any value.
 */

function update_user_profile($id)
{
    global $email, $name, $conn;


    $sql = "UPDATE `admin_details` SET `admin_name`='$name',`email`='$email'  WHERE `admin_id`='$id'";
    print_r($sql);
    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        $msg = "your profile successfully updated";
        $_SESSION['admin_name'] = $name;
        header("Location: http://practice.indianexpress.com/project1/admin/profile.php?msg=$msg");

    }

}
// $submit = $_POST['submit'];

if (isset($submit)) {
    if ($submit == "Update Password") {
        $id = $_POST['uid'];
        change_user_password($id);
    }


}
/*
 * Function - change_user_password(): It update  the password field in admin details table data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table- admin.
 * Return  value: data type- void , return value - does not return any value.
 */


function change_user_password($id)
{
    $msg1 = "retype password and new password field does not matched";
    $msg2 = "Your password successfully updated";
    global $oldpass, $newpass, $confirmpass, $conn;


    if ($newpass == $confirmpass) {


        $sql = "UPDATE `admin_details` SET `password`='$confirmpass' WHERE `admin_id`='$id'";

        $result = mysqli_query($conn, $sql) or die('query failed');
        if ($result) {
            echo "success";
            header("Location: http://practice.indianexpress.com/project1/admin/profile.php?msg2=$msg2");

        }

    } else {
        header("Location: http://practice.indianexpress.com/project1/admin/profile.php?msg1=$msg1");
    }
}


?>