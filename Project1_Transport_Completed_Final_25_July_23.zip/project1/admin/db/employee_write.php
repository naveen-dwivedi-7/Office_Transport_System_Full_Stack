<?php
include_once("db.php");
include_once("employee_read.php");

/*Registration_form */

function no_of_email_already_in_employee_table($email)
{
    global $conn;
    $sql_email_check = "SELECT * FROM employee WHERE email='$email'";
    $result_email = mysqli_query($conn, $sql_email_check);
    $num_emails = mysqli_num_rows($result_email);
    return $num_emails;
}






if ($_GET['val'] == "register") {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $emp_profile = $_POST['emp_profile'];

    if (no_of_email_already_in_employee_table($email) == 0) {

        insert_employee1($fname, $lname, $email, $gender, $dob, $emp_profile);
    } else {
        $msg = "Sorry... you cannot registered this email is already taken";
        echo $msg;
        // header("Location: http://practice.indianexpress.com/project1/register_form.php?msg=$msg");
    }


}

function insert_employee1($fname, $lname, $email, $gender, $dob, $emp_profile)
{
    global $conn;


    $sql = "INSERT INTO `employee`( `fname`, `lname`, `email`, `gender`, `dob`, `emp_profile`) VALUES ('$fname','$lname','$email','$gender','$dob','$emp_profile')";
    if (mysqli_query($conn, $sql)) {
        $msg = "You Registered sucessfully";

    }

    echo $msg;

    // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
}


$id = $_GET['id'];
$status = $_GET['status'];


if ($status == 1) {
    $status = 0;
} else if ($status == 0) {
    $status = 1;
}

if (isset($id)) {
    if ($_GET['action'] == "delete") {
        delete_employee($id);
        delete_employee_time_relation($id);

    } else if ($_GET['action'] == "status") {
        update_status($id);


    }
}

global $emp_profile, $last_emp_id;

if (isset($_FILES['emp_profile'])) {

    $file_name = $_FILES['emp_profile']['name'];
    $emp_profile = "upload_images/" . $file_name;
    $file_size = $_FILES['emp_profile']['size'];
    $file_tmp_name = $_FILES['emp_profile']['tmp_name'];
    $file_type = $_FILES['emp_profile']['type'];
    if (move_uploaded_file($file_tmp_name, "upload_images/  $file_name")) {
        // echo "File Uploaded successsfully";
    } else {
        echo "fails to upload a file";
    }

}




if (!empty($_POST['fname']) && isset($_POST['fname']) && filter_var($_POST['fname'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['fname'])) {
    $fname = $_POST['fname'];
}
if (!empty($_POST['lname']) && isset($_POST['lname']) && filter_var($_POST['lname'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['lname'])) {
    $lname = $_POST['lname'];
}
if (!empty($_POST['email']) && isset($_POST['email']) && filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) && mysqli_real_escape_string($conn, $_POST['email'])) {
    $email = $_POST['email'];
}
if (!empty($_POST['dob']) && isset($_POST['dob']) && filter_var($_POST['dob'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['dob'])) {
    $dob = $_POST['dob'];
}




if (!empty($_POST['gender']) && isset($_POST['gender']) && filter_var($_POST['gender'], FILTER_SANITIZE_STRING) && mysqli_real_escape_string($conn, $_POST['gender'])) {
    $gender = $_POST['gender'];
}

if (!empty($_POST['location_id']) && isset($_POST['location_id']) && filter_var($_POST['location_id'], FILTER_SANITIZE_NUMBER_INT) && mysqli_real_escape_string($conn, $_POST['location_id'])) {
    $location_id = $_POST['location_id'];
}


if (!empty($_POST['submit'])) {
    $submit = $_POST['submit'];
}




$post_time_ids = $_POST['timing_list'];


$no_of_post_time_ids = count($post_time_ids);


print_r($_FILES);

die();


if (isset($submit)) {
    if ($submit == "Update Employee") {
        $id = $_POST['uid'];

        echo "checked time id for given id in relation db are:$id";
        $result = get_employee_checked_time_id_from_relation_table($id);
        $time_ids_checked_array = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $time_ids_checked_array[] = $row['time_id'];

        }
        echo "<pre>";
        print_r($time_ids_checked_array);

        update_employee($id);
        update_employee_time_relation($id, $time_ids_checked_array);
    }
    if ($submit == "Save Employee") {
        insert_employee();


    }

} else {
    echo "Update/Insert Query failed";
}


/*
 *Function - insert_employee(): It insert the fname , lname, gender, route id , employee profile image , and location field values  into employee tables fetched from form submitted by user.
 * Parameters-data type- void ,it  does not take a  parameter;
 * Return  value: data type- void , return value - does not return any value.
 */

function insert_employee()
{
    global $conn, $fname, $lname, $email, $gender, $dob, $emp_profile, $location_id;

    $sql = "INSERT INTO `employee`(`fname`, `lname`,`email`, `gender`, `dob`,`emp_profile`, `location_id`) VALUES ('$fname','$lname','$email','$gender','$dob','$emp_profile','$location_id')";
    if (mysqli_query($conn, $sql)) {
        // echo "New record created successfully";
        $last_emp_id = mysqli_insert_id($conn);
        echo "$last_emp_id";
        insert_employee_time_relation($last_emp_id);
    }



    // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
}



/*
 * Function - update_employee(): It update  the  fname , lname, gender, route id , employee profile image , and location field values  into employee  data fetched from form submitted by user after editing it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-employee .
 * Return  value: data type- void , return value - does not return any value.
 */
function update_employee($id)
{
    global $conn, $fname, $lname, $email, $gender, $dob, $emp_profile, $location_id;
    $sql = "UPDATE `employee` SET `fname`='$fname',`lname`='$lname',`email`='$email',`gender`='$gender',`dob`='$dob',`emp_profile`='$emp_profile',`location_id`='$location_id' WHERE `emp_id`='$id'";

    $result = mysqli_query($conn, $sql) or die('query failed');
    if ($result) {
        echo "success";
        // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");

    }

}





/*
 *Function - delete_employee(): It delete  all the details/field values in employee table with respect to given id passed to it .
 * Parameters-data type- integer ,it take a  parameter -id which is primary key of  table-employee.
 * Return  value: data type- void , return value - does not return any value.
 */


function delete_employee($id)
{
    global $conn;
    $sql = "DELETE FROM `employee` WHERE `emp_id`=$id";

    if (mysqli_query($conn, $sql)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");

}



function insert_employee_time_relation($id)
{
    global $conn, $post_time_ids;
    foreach ($post_time_ids as $item) {
        $sql = "INSERT INTO `employee_timing_relation`(`emp_id`, `time_id`) VALUES ($id,$item)";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "record inserted successfully";
            // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
        }

    }


}

function insert_new_time_id($id, $new_time_id)
{
    global $conn;
    $sql = "INSERT INTO `employee_timing_relation`(`emp_id`, `time_id`) VALUES ($id,$new_time_id)";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
    }


}
function delete_old_time_id($id, $checked_old_time_id)
{
    global $conn;
    $sql = "DELETE FROM `employee_timing_relation` WHERE employee_timing_relation.emp_id='$id' AND employee_timing_relation.time_id='$checked_old_time_id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        // header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
    }


}


function update_employee_time_relation($id, $time_ids_checked_array)
{
    global $conn, $post_time_ids;
    foreach ($post_time_ids as $new_time_id) {
        if (!in_array($new_time_id, $time_ids_checked_array))
            insert_new_time_id($id, $new_time_id);

    }
    foreach ($time_ids_checked_array as $checked_old_time_id) {
        if (!in_array($checked_old_time_id, $post_time_ids))
            delete_old_time_id($id, $checked_old_time_id);

    }

    header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");
}
function delete_employee_time_relation($id)
{
    global $conn;
    $sql = "DELETE FROM `employee_timing_relation` WHERE emp_id='$id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "success";
        header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");

    }

}


function update_status($id)
{
    global $conn, $status;
    $sql = "UPDATE `employee` SET status='$status' WHERE `emp_id`='$id'";

    if (mysqli_query($conn, $sql)) {
        echo "Status updated successfully";
    } else {
        echo "Error while updating status: " . mysqli_error($conn);
    }
    header("Location: http://practice.indianexpress.com/project1/admin/employee_list.php");

}





/* Book Routes */


?>