<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>
<div class="content">
    <div class="content-left">
        <h1 class="title">Service<span> Timings </span></h1>
        <div class="morning">
            <h2 class="subtitle">Morning <span> Timeslot</span></h2>
            <p>
                <?php
                $all_morning_time_ids = get_all_distinct_morning_time_ids();
                $sno = 1;
                foreach ($all_morning_time_ids as $time_id) { ?>
                <h2>
                    <?php $timeSlot = get_time_slot_by_time_id($time_id);

                    echo $sno++; ?>

                    <a style="text-decoration: none"
                        href="http://practice.indianexpress.com/project1/timing_detail.php?timeperiod=M&time_id=<?php echo $time_id ?>">
                        <?php echo $timeSlot ?>
                    </a>

                </h2>


                <div class="row1">

                    <ul class="list1">
                        <li>
                            <?php $no_of_routes = get_number_of_routes_from_given_timeslot($time_id);
                            echo "Total Number of routes in Service : $no_of_routes ";
                            ?>
                        </li>

                    </ul>

                </div>
            <?php } ?>





            </p>
        </div>
        <br>
        <br>
        <br>
        <div class="evening">

            <h2 class="subtitle">Evening <span>Timeslot</span></h2>
            <p>
                <?php
                $all_morning_time_ids = get_all_distinct_evening_time_ids();
                $sno = 1;
                foreach ($all_morning_time_ids as $time_id) { ?>
                <h2>
                    <?php $timeSlot = get_time_slot_by_time_id($time_id);

                    echo $sno++; ?>

                    <a style="text-decoration: none"
                        href="http://practice.indianexpress.com/project1/timing_detail.php?timeperiod=E&time_id=<?php echo $time_id ?>">
                        <?php echo $timeSlot ?>
                    </a>

                </h2>


                <div class="row1">

                    <ul class="list1">
                        <li>
                            <?php $no_of_routes = get_number_of_routes_from_given_timeslot($time_id);
                            echo "Total Number of routes in Service : $no_of_routes ";
                            ?>
                        </li>

                    </ul>
                </div>
            <?php } ?>





            </p>
        </div>
        <p>&nbsp;</p>
        <!-- <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p> -->
        <!-- <p><a href="#" class="more">Read More</a></p> -->
        <!-- 

        <div class="row1">
            <h2 class="subtitle">About <span>Us</span></h2>
            <p><strong>Lorem Ipsum is simply dummy text</strong> of the printing
                and typesetting industry. Lorem Ipsum has been the indusstandard dummy
                text ever since the 1500s, when an unknown printer took a galley of
                type and scrambleto make a type specimen book.</p>
            <p>&nbsp;</p>
            <p>It has survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release </p>
            <ul class="list1">
                <li>of Letraset sheets containing</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
                <li>Lorem Ipsum passages,</li>
                <li>and more recently with desktop</li>
            </ul>
            <p>&nbsp;<br>
                Lorem Ipsum is simply dummy textof the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard
                dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it.<br>
                <br>
            </p>
            <p><a href="#" class="more">Read More</a></p>
        </div> -->
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>
<?php include_once('templates/footer.php'); ?>