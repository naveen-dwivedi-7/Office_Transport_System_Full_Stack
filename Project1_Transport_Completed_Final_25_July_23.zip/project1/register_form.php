<?php
include_once('templates/header.php');
include_once('db_frontend_read.php');
?>
<div id="display1">


</div>
<div class="content">
    <div class="content-left">
        <div class="row1">
            <h1 class="title">Registration <span>Form</span></h1>
            <h2 class="subtitle">Fill below form<span> to use our services</span></h2>

            <?php



            ?>
        </div>

        <div class="feedback-form">
            <div>
                <form id="register_form" enctype="multipart/form-data">
                    <input type="text" name="fname" id="fname" placeholder="First Name"></input>
                    <input type="text" name="lname" id="lname" placeholder="Last Name"></input>
                    <input type="text" name="email" id="email" placeholder="Email"></input>
                    <label for="required">Gender:</label>
                    <input type="radio" name="gender" id="gender" value="male" />Male

                    <input type="radio" name="gender" id="gender" value="female" />Female
            </div>
            <label>Choose DOB</lable>
                <input type="date" name="dob" id="dob" placeholder="Enter Date of birth">
                <label>Choose Profile Picture</lable>
                    <input type="file" name="emp_profile" id="emp_profile" placeholder="Choose Profile Pic">
                    <input type="hidden" name="submit" id="submit_data" value="register">
                    <button type="submit" name="submit" value="register">Register</button>
                    </form>
        </div>

        <?php
        // if (isset($_GET['msg'])) {
        //     echo "<div class='alert alert-danger'>
        //         $_GET[msg]
        //        </div>";
        // } else {
        //     echo 'abcc';
        // }
        ?>
    </div>
    <?php include_once('templates/sidebar.php'); ?>
</div>

</div>
<?php include_once('templates/footer.php'); ?>