<?php

//die();

//Array ( [page] => 2 [action] => pagination )
// Database connection file
if (isset($_POST['action']) && $_POST['action'] == 'pagination') {
    if (isset($_POST['page'])) {
        $page = $_POST['page'];
        include_once('db_frontend_read.php');
        include_once('admin/templates/common.php');
        display_evening_table($page);
        //echo $page;
    }
}

function display_evening_table($cur_page)
{
    global $conn;
    $offset = ($cur_page - 1) * LIMIT;
    //$start_from = get_start_from_value_morning($cur_page);
    $sql = "SELECT * FROM routes WHERE timeperiod='E' ORDER BY route_id DESC LIMIT " . LIMIT . " OFFSET $offset ";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) { ?>
        <?php
        $loc_id = $row['location_id'];
        $location = get_location_name_by_location_id($row['location_id']);
        if (empty($location)) {
            $location = "Data Not Found";
        } ?>
        <h2>From
            <?php echo " office to " ?>
            <a style="text-decoration: none"
                href="http://practice.indianexpress.com/project1/location_detail.php?loc_id=<?php echo $loc_id ?>">
                <?php echo "$location" ?>
            </a>
        </h2>
        <?php
        $timeslot = get_time_slot_by_time_id($row['time_id']);
        $data = get_vehicle_data_by_vehicle_id($row['vehicle_id']);
        $model = $data['model'];
        $capacity = $data['capacity'];
        $distance = get_location_distance_by_location_id($row['location_id']);
        $route_id = $row['route_id'];
        if (empty($distance)) {
            $distance = "Data Not Found";
        } ?>

        <ul class="list1">
            <li>
                <?php echo "Distance: $distance Km" ?>
            </li>
            <li>
                <?php echo "Time: $timeslot" ?>
            </li>
            <li>
                <?php echo " Vehicle: $model " ?>
            </li>
            <li>
                <?php echo "Capacity: $capacity " ?>
            </li>
        </ul>
        <p><a href="book_route.php?r_id=<?php echo $route_id ?>" class="more">Book Route</a></p>
    <?php }
}