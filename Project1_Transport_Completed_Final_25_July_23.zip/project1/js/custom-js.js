
//pagination using ajax and jquery, php



$(".pagination_links").on("click", function (e) {
    e.preventDefault();
    var curr_page = $('#curr_page').html();
    var last_page = $('#last_page').html();

    // alert(curr_page);
    curr_page = parseInt(curr_page, 10);
    last_page = parseInt(last_page, 10);
    // alert(last_page);
    var page = $(this).data('page');

    if (!$.isNumeric(page) && $.isNumeric(curr_page)) {
        if (page === 'prev') {
            page = curr_page - 1;
        } else if (page === 'next') {
            page = curr_page + 1;
        }
    }

    page = parseInt(page, 10);

    // alert("span page--" + curr_page + "-- page-- " + page);
    var ajaxurl = $('#list_content').data('ajaxurl');

    $.ajax
        ({
            type: "post",
            url: ajaxurl,
            data: {
                page: page,
                action: 'pagination',
            },
            success: function (data_1) {
                $('#list_content').html('');
                $('#list_content').html(data_1);
                console.log(data_1);
                $('#curr_page').html(page);
                $('.pagination_links').removeClass('active');
                $('#page_link_' + page).addClass('active');
                if (page === 1) {
                    $('#prev_link').hide();
                    $('#next_link').show();
                } else if (page === last_page) {
                    $('#next_link').hide();
                    $('#prev_link').show()
                } else {
                    $('#prev_link').show();
                    $('#next_link').show();
                }
            }
        });

});






function get_location_select_value() {
    var location_selectedValue = document.getElementById("location_id").value;
    document.cookie = "location_selectedValue=" + location_selectedValue;
    console.log(location_selectedValue);
    document.cookie = "location_selectedValue=" + location_selectedValue;



}
function get_time_select_value() {

    var time_selectedValue = document.getElementById("time_id").value;
    document.cookie = "time_selectedValue=" + time_selectedValue;
    console.log(time_selectedValue);


}
function get_route_select_value() {

    var route_selectedValue = document.getElementById("route_id").value;
    console.log(route_selectedValue);


}
$().ready(function () {
    jQuery.validator.addMethod("noSpace", function (value, element) {
        return value == '' || value.trim().length != 0;
    }, "No space please and don't leave it empty");

    // validation route form

    $("#contact_form").validate({
        rules: {
            name: {
                required: true,
            },
            email: {
                required: true,
            },
            mobile: {
                required: true,
            },
            meassage: {
                required: true,
            },
        },

        messages: {

            name: {
                required: "Please Enter Your Name",

            },
            email: {
                required: "Please Enter Your Email",

            },

            mobile: {
                required: "Please Enter Your Phone no",

            },
            message: {
                required: "Please Enter Your Message",

            },

        },



    });
    $("#register_form").validate({



        rules: {


            fname: {
                required: true,
                noSpace: true,
                minlength: 3
            },
            lname: {
                required: true,
                noSpace: true,
                minlength: 3

            },
            email: {
                required: true,


            },

            dob: {
                required: true,

            },

            profile_img: {
                required: true,

            },






        },

        errorPlacement: function (error, element) {
            if (element.is(":radio")) {
                error.insertAfter(element.parent());
            } else if (element.is(":checkbox")) {
                error.insertAfter(element.parent().parent());
            } else {
                // This is the default behavior of the script for all fields
                error.insertAfter(element);
            }
        },


        messages: {

            fname: {
                required: " Please enter a firstname ",
                minlength: " Your first name must consist of at least 3 characters"
            },
            lname: {
                required: " Please enter a lastname",
                minlength: " Your last name must consist of at least 3 characters"
            },
            email: {
                required: " Please enter your email",

            },
            dob: {
                required: " Please enter a dob",

            },

            profile_img: {
                required: " Please upload your  a image",

            },





        },
        submitHandler: function (form) {

            // insert  and update employee using ajax and php 

            $.ajax({
                url: './admin/db/employee_write.php?val=register',
                type: 'POST',
                data: $("#register_form").serialize(),

                success: function (result) {
                    var action = $(submit_data).val();
                    alert(result);

                    if (action == "Save Employee") {
                        alert("data inserted successfully ");
                    }
                    if (action == "Update Employee") {
                        alert("data updated successfully ");
                    }

                }

            });

        }
    });
});