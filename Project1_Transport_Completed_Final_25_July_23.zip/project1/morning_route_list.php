<?php
include_once('db_frontend_read.php');
include_once('admin/templates/common.php');
include_once('morning_route_read.php');
$page_name = 'Morning List Page';
include_once('templates/header.php');

//$start_from = get_start_from_value_morning($cur_page);
?>

<body>
    <div class="container-xl">
        <br>
        <div class="col-md-12">
            <br>
            <div id="list_content" data-ajaxurl="morning_route_read.php">
                <?php display_morning_table($cur_page); ?>
            </div>
        </div>
        <?php
        $total_rows = get_total_num_of_table_row_morning('routes');
        $total_number_of_pages = ceil($total_rows / LIMIT);
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>