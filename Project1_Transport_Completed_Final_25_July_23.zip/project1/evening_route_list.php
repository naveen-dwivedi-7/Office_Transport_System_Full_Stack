<?php
include_once('db_frontend_read.php');
include_once('admin/templates/common.php');
include_once('evening_route_read.php');
$page_name = 'Evening List Page';
include_once('templates/header.php');

?>

<body>
    <div class="container-xl">
        <br>
        <div class="col-md-12">
            <br>
            <div id="list_content" data-ajaxurl="evening_route_read.php">
                <?php display_evening_table($cur_page); ?>
            </div>
        </div>
        <?php
        $total_rows = get_total_num_of_table_row_evening('routes');
        $total_number_of_pages = ceil($total_rows / LIMIT);
        pagination_links($total_number_of_pages);
        ?>

    </div>
</body>
<?php
include('templates/footer.php');
?>